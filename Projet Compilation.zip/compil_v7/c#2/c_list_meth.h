#include "types.h"

typedef enum{OBJECT_METH,CLASS_METH,CONSTRUCTOR_METH}type_meth;

typedef struct info_param{

	char nom_variable[100];
	typetoken type_variable;
	typetoken passage_variable;
	/*boolean var_ini;*/
	double val_var;
	int ligne_decl;

}info_param;


typedef struct MET_STOCK{
	type_meth type;
	int ligne_decl;
	typetoken access_modif_1;//public|private|internal|protected
	typetoken access_modif_2;//STATIC|ABSTRACT
	typetoken return_type_fct;//INT|DOUBLE|FLOAT
	char nom_fct[50];//nom de la fonction
	int nbre_param;
	int nbre_var;
	info_param list_param_meth[20];
	varvalueType list_variable[100];	
}MET_STOCK;


int erreur_semantique(int ligne,typetoken type_var,typetoken type_val,char *var,char *val);
int var_exist(char *nom_var,int ligne);

//void stocker_variable(char *nom_variable,typetoken type_variable,int ligne_decl,char *val_var,typetoken passage_variable);
void stocker_para(info_param para);
void cree_tab_para();

//void stocker_methode(typetoken access_modif_1,typetoken access_modif_2,typetoken return_type_fct,char *nom_fct,int ligne_decl,int nbre_param);
void stocker_methode(MET_STOCK meth,varvalueType *TS,int length);
int exist_methode_duplicate(typetoken type,char *nom_fct);

void free_tab_para();
void afficher_meth();
void copier_tab_par();
void copier_tab_var(varvalueType *TS,int length);
