#!/bin/sh
./zzp < $1 >tmp 
