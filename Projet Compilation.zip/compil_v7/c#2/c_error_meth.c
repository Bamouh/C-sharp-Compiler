#include<stdio.h>
#include "c_error_meth.h"
#include<stdlib.h>
#include<string.h>



typedef struct stockage{
int ligne;
char nom_erreur[100];
SemanticErrorMeth et;
}stockage;


stockage *tab_erreur=NULL;//stocker les erreurs//
int index_erreur=0;
int erreur_sem=0;


void cree_file_error(){
	tab_erreur=(stockage *)malloc(100*sizeof(stockage));
}

void cree_sm_error(SemanticErrorMeth et,int ligne,char *name){
	erreur_sem++;	
	tab_erreur[index_erreur].ligne=ligne;
	strcpy((tab_erreur+index_erreur)->nom_erreur,name);
	tab_erreur[index_erreur].et=et;
	index_erreur++;
}

int nombre_erreur(){
	return erreur_sem;
}

void afficher_erreur(){
	printf("nombre d'erreur sémantique est : %d\n",erreur_sem);
	int i;
	for(i=0;i<index_erreur;i++){ 
		if(tab_erreur[i].et==DUPLICATE_METH) printf("ligne %d : %s METH duplicated\n",tab_erreur[i].ligne,tab_erreur[i].nom_erreur);
		if(tab_erreur[i].et==PARAM_DEJA_DECL)	printf("ligne %d : %s parametre duplicated\n",tab_erreur[i].ligne,tab_erreur[i].nom_erreur);
		if(tab_erreur[i].et==MET_MAIN_NN_STATIC)	printf("ligne %d : %s devra etre static\n",tab_erreur[i].ligne,tab_erreur[i].nom_erreur);
	}
}








