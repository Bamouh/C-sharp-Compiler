#!/bin/sh
./zzc < $1 | ./zzi
