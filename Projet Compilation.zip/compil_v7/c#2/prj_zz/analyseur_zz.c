#include <stdio.h>
#include <string.h>
#include "analyseur.h"
#include "tablesymb.h"
#include "types.h"
#include "error.h"
#include "pseudocode.h"
#include "vm.h"

// a supprimer
#define debug false

#include <stdlib.h>

// auteur Karim Baïna, ENSIAS, Décembre 2010, puis Décembre 2011, puis Décembre 2012 et corrigé en Décembre 2013

// gérer l'associatvité gauche des opérateurs binaires (AST gauches) avec une grammaire récursive non gauche (LL(1))

/* 
 PROG : LISTE_DECL begin LISTE_INST end
 LISTE_INST : INST LISTE_INSTAUX
 LISTE_INSTAUX : LISTE_INST  | epsilon
 LISTE_DECL : DECL LISTE_DECLAUX 
 LISTE_DECLAUX : LISTE_DECLAUX : LISTE_DECL | epsilon
 DECL : idf TYPE DECL_AUX
 DECL_AUX : CONST ';' | ';'
 TYPE : int | bool ==>TYPE : int | bool | double ; 
 CONST : inumber | dnumber | true | false
 INST : INST : idf = ADDSUB | true | false ';' 
      | if ‘(‘ idf == ADDSUB ‘)’ then LISTE_INST IF_INSTAUX 
      | print IDF ';'
      | for IDF = dnumber to dnumber do LISTE_INST endfor
 IF_INSTAUX :  endif  | else LISTE_INST endif

 ADDSUB : MULTDIV ADDSUBAUX

 ADDSUBAUX : – MULTDIV ADDSUBAUX
 ADDSUBAUX : + MULTDIV ADDSUBAUX
 ADDSUBAUX : epsilon

 MULTDIV : AUX MULTDIVAUX

 MULTDIVAUX : * AUX MULTDIVAUX ==> * MULTDIV
 MULTDIVAUX : / AUX MULTDIVAUX ==> / MULTDIV
 MULTDIVAUX : epsilon

 AUX : idf
 AUX : num
 AUX : ( ADDSUB )

*/

boolean _prog(listinstvalueType ** pplistinstattribute);

boolean _liste_inst(listinstvalueType ** pplistinstattribute);
boolean _liste_inst_aux(listinstvalueType ** pplistinstattribute);
boolean _inst(instvalueType ** ppinstattribute);
boolean _if_inst_aux(listinstvalueType ** pplistinstattribute);

boolean _liste_decl();
boolean _liste_decl_aux();
boolean _decl();
boolean _decl_aux();
boolean _type();
boolean _const();

boolean _addsub(AST *past);
boolean _addsubaux(AST *past);
boolean _multdiv(AST *past);
boolean _multdivaux(AST *past);
boolean _aux(AST *past);

//void _yyless(char *tokenimage); depricated : remet la chaîne paramètre à l'entrée standard

typetoken _lire_token();

extern int yylex();

typetoken token; 
boolean follow_token = false;

varvalueType varattribute;
constvalueType constattribute;
typevalueType typeattribute;
instvalueType instattribute;
listinstvalueType listinstattribute;
tokenvalueType tokenattribute;

int rangvar;
boolean semanticerror = false;

int main(int argc, char * argv){
	listinstvalueType ** pplistinstattribute = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	*pplistinstattribute = NULL;

	token = _lire_token();
	if (_prog(pplistinstattribute) == true) {
		if (debug) ("0 erreurs syntaxiques\n");

		if (nombre_sm_erreurs() == 0){
			if (debug) printf("0 erreurs sémantiques\n");
			if (debug) afficherTS();
			
			if (debug) { 
			printf("Affichage du Control Flow Graph produit :\n"); afficher_list_inst(*pplistinstattribute);
			}
			if (debug) printf("Generation du code ...\n");			
			pseudocode pc = generer_pseudo_code(*pplistinstattribute);
			if (debug) printf("Affichage du pseudocode généré :\n");
			afficher_pseudo_code(pc);
		}else{
			printf("%d erreurs sémantiques\n", nombre_sm_erreurs());
			afficher_sm_erreurs();
		}
	}
	else {
		printf("plusieurs erreurs syntaxiques\n");
		/* printf("%d erreurs syntaxiques\n", nombre_sx_erreurs());
		afficher_sx_erreurs(); */
		
		printf("%d erreurs sémantiques\n", nombre_sm_erreurs());
		if (nombre_sm_erreurs()> 0) afficher_sm_erreurs();
	}
	
return 0;
}
// PROG : LISTE_DECL begin LISTE_INST end
boolean _prog(listinstvalueType ** pplistinstattribute){
	boolean result;
	if (debug) printf("prog()\n");

	if (_liste_decl()) {
		token = _lire_token();
		if (token == BEG_IN){
			token = _lire_token();
			if (_liste_inst(pplistinstattribute)) {
				token = _lire_token();
				if (token == END){
					result = true;
				} else {
					result = false;
				}
			}else result = false;
		}else{
			
			// creer_sx_erreur(BeginExpected, tokenattribute.line);
			// déjà traité dans le nullable liste_decl !!
			
			result = false;
		}
	}else result = false;
	
	if (debug) printf("out of prog()\n");
	return result;
}

// LISTE_INST : INST LISTE_INSTAUX
boolean _liste_inst(listinstvalueType ** pplistinstattribute){
	boolean result;
	if (debug) printf("list_inst()\n");

	instvalueType ** ppinstattribute = (instvalueType **) malloc(sizeof(instvalueType *));
	*ppinstattribute = NULL;

	if (_inst(ppinstattribute)) {
		// bugg !! les ast ne sont pas termines printf("new inst ===>");afficher_inst(**ppinstattribute);
		token = _lire_token();
		if (_liste_inst_aux(pplistinstattribute) == true){
			if (semanticerror != true) inserer_inst_en_tete(pplistinstattribute, **ppinstattribute);
			result = true;
		}else result = false;
	}else result = false;

	if (debug) printf("out of list_inst()\n");
	return result;
}

// LISTE_INSTAUX : LISTE_INST  | epsilon
// NULLABLE(LISTE_INSTAUX) = true
// follow(LISTE_INSTAUX) = {end, endif, else, endfor}
// first(LISTE_INSTAUX) = {idf}
boolean _liste_inst_aux(listinstvalueType ** pplistinstattribute){
        boolean result;
	if (debug) printf("list_inst_aux()\n");

	if (token == END){
		// _yyless("\tend\n");
		follow_token = true;
		* pplistinstattribute = NULL;
		result = true;
	} else if (token == ENDIF){
		// _yyless("\tendif\n");
		follow_token = true;
		* pplistinstattribute = NULL;
		result = true;
	} else if (token == ELSE){
		// _yyless("\telse\n");
		follow_token = true;
		* pplistinstattribute = NULL;
		result = true;
	} else if (token == ENDFOR){
		// _yyless("\telse\n");
		follow_token = true;
		* pplistinstattribute = NULL;
		result = true;
	} else if (_liste_inst(pplistinstattribute) == true){
		result = true;
	} else result = false;

	if (debug) printf("out of list_inst_aux()\n");	
	return result;
}

//  INST : idf = ADDSUB ';'
//         | IDF = TRUE ';'
//         | IDF = FALSE ';'
//         | if ‘(‘ idf == ADDSUB ‘)’ then LISTE_INST IF_INSTAUX
//         | print IDF ';'
//         | for IDF = dnumber to dnumber do LISTE_INST endfor
boolean _inst(instvalueType ** ppinstattribute){
	boolean result;
	if (debug) printf("inst()\n");

	AST *past = (AST *) malloc(sizeof(AST)); // NEW
	(*past) = (AST) malloc(sizeof(struct Exp));
	listinstvalueType ** pplistthen = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	listinstvalueType ** pplistelse = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	listinstvalueType ** pplistfor = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	*pplistthen = NULL;
	*pplistelse = NULL;
	*pplistfor = NULL;

	* ppinstattribute = NULL;

	int localrangvar; constvalueType borneinfconstattribute, bornesupconstattribute, localconstattribute; varvalueType localvarattribute;
	//    for IDF = inumber to inumber do LISTE_INST endfor
	if (token == FOR){
		token = _lire_token();
		if (token == IDF){
			if (inTS(varattribute.name, &localrangvar) == false) {
					semanticerror = true ;
					creer_sm_erreur_instruction(NotDeclared, varattribute.line, varattribute.name);
			}
			token = _lire_token();
			if (token == EQ) {
				token = _lire_token();
				if (token == INUMBER) {
					borneinfconstattribute = constattribute;
					token = _lire_token();
					if (token == TO) {
						token = _lire_token();
						if (token == INUMBER) {
							bornesupconstattribute = constattribute;			
							token = _lire_token();
							if (token == DO) {
								token = _lire_token();
								if (_liste_inst(pplistfor)) {
									token = _lire_token();
									if (token == ENDFOR){
										result = true;
										if (semanticerror != true) 
					*ppinstattribute = creer_instruction_for(localrangvar, borneinfconstattribute.valinit, bornesupconstattribute.valinit,*pplistfor);
									} else result = false;
								}else result = false;
							}else result = false;
						}else result = false;
					}else result = false;
				}else result = false;
			}else result = false;
		}else result = false;
	}else if (token == PRINT){
		token = _lire_token();
		if (token == IDF){
			if (inTS(varattribute.name, &rangvar) == false) {
					semanticerror = true ;
					creer_sm_erreur_instruction(NotDeclared, varattribute.line, varattribute.name);
			}else{
				if (semanticerror != true) *ppinstattribute = creer_instruction_print(rangvar);
			}
			token = _lire_token();
			if (token == PVIRG) {
				result = true;
			}else result = false;
		}else result = false;				
	}else if (token == IDF){
		localvarattribute = varattribute;
		// 1ere gestion erreur NotDeclared : l'IDF (lexp) peut ne pas avoir été déclaré
		if (inTS(localvarattribute.name, &localrangvar) == false){
					if (debug) printf("%sn'y est pas\n ", localvarattribute.name); afficherTS();
					semanticerror = true ;
					creer_sm_erreur_instruction(NotDeclared, localvarattribute.line, localvarattribute.name);
		}
		token = _lire_token();
		if (token == EQ){
			token = _lire_token();
			if (token == TRUE){
				token = _lire_token();
				if (token == PVIRG){
				     if (semanticerror != true){
				     	if (typevar(localrangvar) == Bool) {
						*past = creer_feuille_booleen(true);
						*ppinstattribute = creer_instruction_affectation(localrangvar, past);
					     }else{
						semanticerror = true ;
						// 2eme gestion erreur IncompatibleAssignType : l'affectation peut être mal typée
						creer_sm_erreur_instruction(IncompatibleAssignType, localvarattribute.line, localvarattribute.name);
					     }
				     }
				     result = true;
				}else{
					result =  false;
				}
			}else if (token == FALSE){
				token = _lire_token();
				if (token == PVIRG){
				     if (semanticerror != true){
					     if (typevar(localrangvar) == Bool){
						*past = creer_feuille_booleen(false);
						*ppinstattribute = creer_instruction_affectation(localrangvar, past);
					     }else{
						semanticerror = true ;
						// 2eme gestion erreur IncompatibleAssignType : l'affectation peut être mal typée
						creer_sm_erreur_instruction(IncompatibleAssignType, localvarattribute.line, localvarattribute.name);
					     }
				     }
				     result = true;
				}else{
					result =  false;
				}
			}else if (_addsub(past)){
				// Ce traitement n'a de sens que si la variable a bien été déclarée !!
				if ( (semanticerror != true) && (typevar(localrangvar) != type(*past)) ){ //Double/Int, Int/Double, Bool/Int, Bool/Double
					if (debug) 
					printf("typelexp(%s) == %s\n",name(localrangvar),(typevar(localrangvar)==Int)?"Int":((typevar(localrangvar)==Double)?"Double":"Boolean"));
					if (debug) printf("typerexp == %s\n",(type(*past)==Int)?"Int":((type(*past)==Double)?"Double":"Boolean"));
				     if ( (typevar(localrangvar) == Double) && (type(*past) == Int)){
					(*past)->typename = Double; // Casting implicit Double = (Double) Int
				     }else{
					semanticerror = true ;
					// 2eme gestion erreur IncompatibleAssignType : l'affectation peut être mal typée
					creer_sm_erreur_instruction(IncompatibleAssignType, localvarattribute.line, localvarattribute.name);
				     }
				}
				token = _lire_token();
				if (token == PVIRG){
					// Ce traitement n'a de sens que si la variable a bien été déclarée !!
					if (semanticerror != true)
						*ppinstattribute = creer_instruction_affectation(localrangvar, past);
					result = true;
				} else result = false;
			} else result = false;		
		} else result = false;
	}else if (token == IF){
		token = _lire_token();
		if (token == POPEN){
			token = _lire_token();
			if (token == IDF){
				localvarattribute = varattribute;
				// 3eme gestion erreur NotDeclared : l'IDF (lexp) peut ne pas avoir été déclaré
				if (inTS(localvarattribute.name, &localrangvar) == false){
							semanticerror = true;		
							creer_sm_erreur_instruction(NotDeclared, localvarattribute.line, localvarattribute.name);
				}else semanticerror = false;
				token = _lire_token();
				if (token == EQEQ){
					token = _lire_token();
					if (_addsub(past)){
						// N'a vraiement de sens que s'il n'y pas d'erreur sémantique dans la déclaration du IDF
						if ( (semanticerror != true) && (typevar(localrangvar) != type(*past) ) ){ //Int/Double, Double/Int, Double/Bool, Bool/Double, Int/Bool, Bool/Int
							// 4eme gestion erreur IncompatibleCompType : la conditionnelle peut être mal typée
							if ((typevar(localrangvar) == Bool) || (type(*past) == Bool)){ // Double/Bool, Bool/Double, Int/Bool, Bool/Int
								semanticerror = true;
								creer_sm_erreur_instruction(IncompatibleCompType, localvarattribute.line, localvarattribute.name);
							}// else casting implicite pas besoin de faire de traitement !! pour Int/Double, Double/Int
						}
						token = _lire_token();
						if (token == PCLOSE){
							token = _lire_token();
							if (token == THEN){
								token = _lire_token();
								if (_liste_inst(pplistthen)){
									token = _lire_token();
									if (_if_inst_aux(pplistelse) == true){

										// N'a de sens que s'il n'y pas d'erreur sémantique dans tout le IF !!
										if (semanticerror != true)
											*ppinstattribute = creer_instruction_if(localrangvar, past, *pplistthen, *pplistelse);
										//if (debug) afficher_inst(**ppinstattribute);
										result = true;
									}else result = false;
								}else result = false;
							}else result = false;
						}else result = false;
					}else result = false;
				} else result = false;
			} else result = false;
		} else result = false;
	} else result = false;


	if (debug) printf("out of inst()\n");
	return result;
}

// IF_INSTAUX :  endif | else LISTE_INST endif
boolean _if_inst_aux(listinstvalueType ** pplistinstattribute){
	boolean result;
	if (debug) printf("if_inst_aux()\n");

	* pplistinstattribute = NULL;

	if (token == ENDIF){
		result = true;
	}else if (token == ELSE){
		token = _lire_token();
		if (_liste_inst(pplistinstattribute) == true){
			token = _lire_token();
			result = (token == ENDIF);
		} else result = false;
	} else result = false;


	if (debug) printf("out of if_inst_aux()\n");
	return result;
}

// LISTE_DECL : DECL LISTE_DECLAUX
boolean _liste_decl(){
	boolean result;
	if (debug) printf("liste_decl()\n");

	if (_decl()){
		token = _lire_token();
		result = _liste_decl_aux();
	}else result = false;

	if (debug) printf("out of liste_decl()\n");
	return result;
}

// LISTE_DECLAUX : LISTE_DECL | '.' ==> LISTE_DECLAUX : LISTE_DECL | epsilon
// NULLABLE(LISTE_DECLAUX) = true
// follow(LISTE_DECLAUX) = {begin}
// first(LISTE_DECLAUX) = {idf}
boolean _liste_decl_aux(){
	boolean result;
	if (debug) printf("liste_decl_aux()\n");

	if ( (token == BEG_IN) ){
		// _yyless("\tbegin\n");
		follow_token = true;
		result = true;
	}else if (_liste_decl()){
		result = true;
	}else{
		/* printf("TOKE = %d\n",token);
		creer_sx_erreur(BeginExpected, tokenattribute.line); */
		result = false;
	}

	if (debug) printf("out of liste_decl_aux()\n");
	return result;
}

// DECL : idf TYPE DECL_AUX
boolean _decl() {
	boolean result;

	if (debug) printf("decl()\n");

	if ( (token == IDF) ) {
		if (debug) printf("VAR{%s}",varattribute.name);
		token = _lire_token();
		if (_type() == true){
			token = _lire_token();
			if (_decl_aux() == true){
				// 5eme gestion erreur AlreadyDeclared : l'IDF peut être déjà déclaré
				if (inTS(varattribute.name, &rangvar) == true) {
					semanticerror = true;
					creer_sm_erreur_declaration(AlreadyDeclared, varattribute.line, varattribute.name);
				}else{
					varvalueType newvar;
					newvar.nbdecl = 1;
			    		newvar.name = (char *)malloc(sizeof(char)*strlen(varattribute.name)+1);
					strcpy(newvar.name, varattribute.name);
					if (debug) printf("VAR{%s}-->NEW{%s}",varattribute.name, newvar.name);
					newvar.line = varattribute.line;
					newvar.initialisation = varattribute.initialisation; // l'initialisation est marquée par decl_aux dans varattribute
				        newvar.typevar = typeattribute.typename;
			      		newvar.valinit = ((varattribute.initialisation == true)?constattribute.valinit:0.0);
					ajouter_nouvelle_variable_a_TS(newvar);
				}

				// 6eme gestion erreur BadlyInitialised : l'IDF peut avoir été initialisé par une constante du mauvais type
				if (varattribute.initialisation == true){
				    if (constattribute.typename != typeattribute.typename){ //Int/Double, Double/Int, Double/Bool, Bool/Double, Int/Bool, Bool/Int
					if ( (typeattribute.typename != Double) || (constattribute.typename != Int) ){  // ce n'est pas Double := Int
						semanticerror = true;
						creer_sm_erreur_declaration(BadlyInitialised, varattribute.line, varattribute.name);
					}
				        //else casting implicit Double = (Double) Int
				    }
				}
	
				result = true;
			}else result = false;
		}else result = false; 
	} else result = false;

	if (debug) printf("out of decl()\n");
	return result;
}

// DECL_AUX : CONST ';' | ';'
boolean _decl_aux() {
	boolean result;
	if (debug) printf("decl_aux()\n");

	if ( (token == PVIRG) ) { 
		varattribute.initialisation = false;		
		result = true; 
	}else if (_const()) {
		token = _lire_token();
		if (token == PVIRG) {
			varattribute.initialisation = true;		
			result = true;
		} else result = false;
		
	}else result = false;

	if (debug) printf("out of decl_aux()\n");
	return result;
}

// TYPE : int | bool ; ==> // TYPE : int | bool | double ; 
boolean _type() {
	boolean result;
	if (debug) printf("type()\n");

	if (token == INT) {typeattribute.typename = Int; result = true;}
	else if (token == DOUBLE) {typeattribute.typename = Double; result = true;}
	else if (token == BOOL) {typeattribute.typename = Bool; result = true;}
	else result = false;

	if (debug) printf("out of type()\n");
	return result;
}

// CONST : number | true | false ; ==> CONST : inumber | dnumber | true | false ; 
boolean _const() {
	boolean result;
	if (debug) printf("const()\n");

	if (token == INUMBER) {
		constattribute.typename = Int;
		result = true;	
	}else if (token == DNUMBER) {
		constattribute.typename = Double;
		result = true;
	} else if ( (token == TRUE) || (token == FALSE) ){
		constattribute.typename = Bool;
		result = true;	
	} else result = false;

	if (debug) printf("out of const()\n");
	return result;
}

// ADDSUB : MULTDIV ADDSUBAUX
// erronée : produit un arbre dégénéré droit (associativité droite aulieu de gauche)
// correction :
// reçoit un arbre [past] en paramètre avec un arbre droit NULL
// lui installe l'arbre reçu de Multidiv comme arbre droit
// le repasse à ADDSUBaux en paramètre
boolean _addsub(AST *past){
	boolean result;
	if (debug) printf("addsub()\n");

	AST *past1 = (AST *) malloc(sizeof(AST));
	AST *past2 = (AST *) malloc(sizeof(AST));

	(*past1) = (AST) malloc (sizeof(struct Exp)); // NEW 
        // NEW 9 : past a un arbre droit NULL
	if (_multdiv(past1)){
		token = _lire_token();

		if ((*past)->noeud.op.expression_gauche == NULL) (*past) = *past1; // initialisation par le première feuille gauche. // NEW 10.1
		else (*past)->noeud.op.expression_droite = *past1; // NEW 10.2

		if (_addsubaux(past) == true){ 
		// if (_addsubaux(past2) == true){ // OLD 11
			/* OLD 12 if ( (*past1 != NULL) && (*past2 != NULL) ){
				char op = ((top(*past2)==plus)?'+':((top(*past2)==moins)?'-':((top(*past2)==mult)?'*':'/')));
				if (debug) printf("--------->type(*past1) ==%s\n",(type(*past1)==Int)?"Int":(type(*past1)==Double)?"Double":"Bool");
				if (debug) printf("--------->type(arbre_droit(*past2)) ==%s\n",(type(arbre_droit(*past2))==Int)?"Int":(type(arbre_droit(*past2))==Double)?"Double":"Bool");
				

					if ( (type(*past1) == type(arbre_droit(*past2))) ){ //Int/Int ou Double/Double
						*past = creer_noeud_operation(op, *past1, arbre_droit(*past2), type(*past1)); // 1ere inférence de type d'arbre arithmétique
					} else{ 
						*past = creer_noeud_operation(op, *past1, arbre_droit(*past2), Double); // casting implicite Int[+,-,*,/]Double ou Double[+,-,*,/]Int ==> Double
					}		
				}*/
				if ((arbre_droit(*past) != NULL) && (arbre_gauche(*past) != NULL)) {
					if (type(arbre_gauche(*past)) == type(arbre_droit(*past))){ // NEW 5 & 6 Int/Int ou Double/Double
						(*past)->typename = type(arbre_gauche(*past));
					}else (*past)->typename = Double;
				}else {(*past) = *past1;} // ??

				/* if (type(arbre_gauche(*past)) == type(arbre_droit(*past))){ // NEW 11 Int/Int ou Double/Double
					(*past)->typename = type(arbre_gauche(*past));
				}else (*past)->typename = Double; */
			// OLD 12 }else *past = *past1;
			result = true;
		}else result = false;
	}else result = false;

	if (debug) printf("out of addsub()\n");
	return result;
}

// ADDSUBAUX : + MULTDIV ADDSUBAUX | - MULTDIV ADDSUBAUX | epsilon
// eq à (ADDSUBAUX : + ADDSUB | - ADDSUB | epsilon)
// erronée : produit un arbre dégénéré droit (associativité droite aulieu de gauche)
// correction :
// reçoit un arbre [past] en paramètre
// crée un nouvel arbre [newpast] dont il place la racine [+ ou -], place [past] à sa gauche avec un arbre droit NULL
// le repasse à ADDSUB en paramètre
// NULLABLE(ADDSUBAUX) = true
// follow(ADDSUBAUX) = { ';' , ')' }
// first(ADDSUBAUX) = { '-' , '+' }
boolean _addsubaux(AST *past){
	boolean result;
	if (debug) printf("addsubaux()\n");

	// *past = NULL; OLDI

	// AST *past1 = (AST *) malloc(sizeof(AST)); ??

	if ( (token == PVIRG) || (token == PCLOSE) ){
		follow_token = true;
		result = true;
	}else if (token == PLUS) {
			token = _lire_token();
			*past = creer_noeud_operation('+', *past, NULL, type(*past)); // NEW 1 : 2eme inférence de type d'arbre arithmétique
			if (_addsub(past) == true){
			// if (_addsub(past1) == true){
				//if (*past1 != NULL)
					//*past = creer_noeud_operation('+', NULL, *past1, type(*past1)); // OLD 1 2eme inférence de type d'arbre arithmétique
				result = true;
			}else result = false;
	} else if (token == MINUS) {
			token = _lire_token();
			*past = creer_noeud_operation('-', *past, NULL, type(*past)); // NEW 2 : 2eme inférence de type d'arbre arithmétique
			if (_addsub(past) == true){
			//if (_addsub(past1) == true){
				// if (*past1 != NULL)
					// *past = creer_noeud_operation('-', NULL, *past1, type(*past1)); // OLD 2 3eme inférence de type d'arbre arithmétique
				result = true;
			}else result = false;
	} else result = false;

	if (debug) printf("out of addsubaux()\n");
	return result;
}

// MULTDIV : AUX MULTAUX
// erronée : produit un arbre dégénéré droit (associativité droite aulieu de gauche)
// correction :
// reçoit un arbre [past] en paramètre avec un arbre droit NULL
// lui installe l'arbre reçu de Aux comme arbre droit
// le repasse à Multdivaux en paramètre
boolean _multdiv(AST *past){
	boolean result;
	if (debug) printf("mult()\n");

	// *past = NULL; OLDI

	AST *past1 = (AST *) malloc(sizeof(AST));
	AST *past2 = (AST *) malloc(sizeof(AST));

        // NEW 3 : past a un arbre droit NULL
	(*past1) = (AST) malloc (sizeof(struct Exp)); // NEW 

	if (_aux(past1)){
		token = _lire_token();
		//if ((*past1) == NULL) printf("PAST1 \n"); // NEW
		//if ((*past) == NULL) printf("PAST\n"); // NEW
		if ((*past)->noeud.op.expression_gauche == NULL) (*past) = *past1; // initialisation par le première feuille gauche.
		else (*past)->noeud.op.expression_droite = *past1; // NEW 3
		//if (arbre_gauche(*past) == NULL) printf("ag(PAST) 1\n"); // NEW
		//if (arbre_droit(*past) == NULL) printf("ad(PAST) 1\n"); // NEW
		if (_multdivaux(past) == true){ // NEW 4
		// if (_multdivaux(past2) == true){ // OLD 4
			/* OLD 5 if ( (*past1 != NULL) && (*past2 != NULL) ){ 
				char op = ((top(*past2)==plus)?'+':((top(*past2)==moins)?'-':((top(*past2)==mult)?'*':'/')));
				if (type(*past1) == type(arbre_droit(*past2))){ //Int/Int ou Double/Double
					*past = creer_noeud_operation(op, *past1, arbre_droit(*past2), type(*past1)); // 4eme inférence de type
				} else {
					*past = creer_noeud_operation(op, *past1, arbre_droit(*past2), Double); // casting implicite Int[+,-,*,/]Double ou Double[+,-,*,/]Int ==> Double
				}*/
				// if (arbre_gauche(*past) == NULL) printf("ag(PAST) 2\n"); // NEW
				if ((arbre_droit(*past) != NULL) && (arbre_gauche(*past) != NULL)) {
					if (type(arbre_gauche(*past)) == type(arbre_droit(*past))){ // NEW 5 & 6 Int/Int ou Double/Double
						(*past)->typename = type(arbre_gauche(*past));
					}else (*past)->typename = Double;
				}else {(*past) = *past1;} // ??
			// OLD 6 }else *past = *past1;
			result = true;
		}else result = false;
	}else result = false;

	if (debug) printf("out of mult()\n");
	return result;
}

// MULTDIVAUX : * AUX MULTDIVAUX | / AUX MULTDIVAUX | epsilon
// eq à (MULTDIVAUX : * MULTDIV | / MULTDIV | epsilon)
// NULLABLE(MULTDIVAUX) = true
// follow(MULTDIVAUX) = { '+' , '-' , ';' , ')' }
// first(MULTDIVAUX) = { '*', '/' }
// erronée : produit un arbre dégénéré droit (associativité droite aulieu de gauche)
// correction :
// reçoit un arbre [past] en paramètre
// crée un nouvel arbre [newpast] dont il place la racine [/ ou *], place [past] à sa gauche avec un arbre droit NULL
// le repasse à MultDiv en paramètre
boolean _multdivaux(AST *past){
	boolean result;
	if (debug) printf("multaux()\n");

	// *past = NULL; OLDI

	// AST *past1 = (AST *) malloc(sizeof(AST));
	
	if ( (token == PLUS) || (token == MINUS) || (token == PVIRG) || (token == PCLOSE) ){
		follow_token = true;
		result = true;
	}else if (token == MULT) {
			token = _lire_token();
			*past = creer_noeud_operation('*', *past, NULL, type(*past)); // NEW 7 : 2eme inférence de type d'arbre arithmétique
			if (_multdiv(past)){
			// if (_multdiv(past)){
				//if ( (*past1 != NULL) )
					//*past = creer_noeud_operation('*', NULL, *past1, type(*past1)); //OLD 7 5eme inférence de type d'arbre arithmétique
				result = true;
			}else result = false;
	} else if (token == DIV) {
			token = _lire_token();
			*past = creer_noeud_operation('/', *past, NULL, type(*past)); // NEW 8 : 2eme inférence de type d'arbre arithmétique
			if (_multdiv(past)){
			// if (_multdiv(past1)){
				// if ( (*past1 != NULL) )
					// *past = creer_noeud_operation('/', NULL, *past1, type(*past1)); //OLD 8 6eme inférence de type d'arbre arithmétique
				result = true;			
			}else result = false;
	} else result = false;

	if (debug) printf("out of multaux()\n");
	return result;
}

// AUX : idf | number | ( ADDSUB ) ==> AUX : idf | inumber | dnumber | ( ADDSUB ) 
boolean _aux(AST *past){
	boolean result;

	// *past = NULL; OLDI

	if (debug) printf("aux()\n");

	if  (token == IDF) {
		// 7eme gestion erreur NotDeclared : l'IDF peut ne pas avoir été déclaré
		if (inTS(varattribute.name, &rangvar) == false) {
			semanticerror = true;
			creer_sm_erreur_instruction(NotDeclared, varattribute.line, varattribute.name);
		
		// 8eme gestion erreur IncompatibleOperationType : l'IDF peut avoir été déclaré d'un type non entier ni double
		}else if ( (typevar(rangvar) != Int) && (typevar(rangvar) != Double) ) { // (si l'IDF est un Bool)
			semanticerror = true;
			creer_sm_erreur_instruction(IncompatibleOperationType, varattribute.line, varattribute.name);
		}else{
			// l'IDF est Int ou Double
			*past = creer_feuille_idf(name(rangvar), typevar(rangvar)); // On ne peut pas donc avoir un AST de type Bool (meme si l'IDF est un Bool)
		}
		result = true;
	} else if (token == INUMBER) {
		*past = creer_feuille_nombre(constattribute.valinit, Int);
		result = true;
	} else if (token == DNUMBER) {
		*past = creer_feuille_nombre(constattribute.valinit, Double);
		result = true;
	}  else if (token == POPEN) {
		token = _lire_token();
		if (_addsub(past)){
			token = _lire_token();
			result = (token == PCLOSE);
		}else result = false;
	} else result = false;


	if (debug) printf("out of aux()\n");
	return result;
}

// depricated : remet la chaîne paramètre (image du token courant) à l'entrée standard
/*void _yyless(char *tokenimage){
	int n = strlen(tokenimage) - 1;
	while (n >= 0)	{ungetc(tokenimage[n], stdin); n--;}
}*/

// lit le prochain token s'il n'a pas déjà été lu par le prédicat d'un nullable
typetoken _lire_token(){
	if (follow_token){
		follow_token = false;
		return token;
	}else{ 
		return (typetoken) yylex();
	}
}

void set_idf_attributes(char *name, int line){
	if (debug) printf("[%s]", name);
	varattribute.name = (char *)malloc(sizeof(char) * strlen(name)+1);
	strcpy(varattribute.name, name);
	if (debug) printf("[%s]", varattribute.name);
	varattribute.line = line;
}

void set_number_attributes(double value){
	constattribute.valinit = value;
}

void set_token_attributes(int line){
	tokenattribute.line = line;
}
