typedef enum{
	DUPLICATE_METH,MET_MAIN_NN_STATIC,PARAM_DEJA_DECL
}
SemanticErrorMeth;

void cree_file_error();
void cree_sm_error(SemanticErrorMeth et,int line,char *name);
int nombre_erreur();
void afficher_erreur();
