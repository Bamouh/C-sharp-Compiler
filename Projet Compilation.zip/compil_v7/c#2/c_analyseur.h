#ifndef ANALYSEUR_CSHARP
#define ANALYSEUR_CSHARP
//Badr-Eddine BAHOUM
#include "ast.h"
#include "types.h"
/*typedef enum{
ACC_OUVR,ACC_FER,ABSTRACT,ADDI,ADD_OPER,AFFECTATION,AND,AND_OPER,AS,BASE,BAR_VERT,BOOL,BREAK,BYTE,CASE,
CATCH,CHAR,CHECKED,CLASS,CONST,CONTINUE,COMMENTS,COMMENTS_2,CRO_OUVR,CRO_FER,DECIMAL,DEFAULT,DELEGATE,
DO,DIV,DIV_OPER,DEUX_PT,DOUBLE,DECREMENT,DNUMBER,EQUIV,ET_COMMER,EQ,ELSE,ENUM,EVENT,EXPLICIT,EXTERN,
FALSE,FINALLY,FIXED,FLOAT,FOR,FOREACH,
GOTO,IF,IMPLICIT,IN,INT,INTERFACE,INF,INF_OR_EQ,INTERNAL,IS,INUMBER,IDF,INCREMENT,LEFT_SHIFT,
LEFT_SHIFT_OPER,LOCK,LONG,MEMBER_ACCESS,MINUS,MINUS_OPER,MUL,MUL_OPER,MODULO,MODULO_OPER,NAMESPACE,
NEGATION,NEW,NOT_EQ,
OBJECT,OPERATOR,OR,OR_OPER,OUT,OVERRIDE,PT_VIRGULE,PT_INTER,PAR_OUVR,PAR_FER,PARAMS,POINT,PRIVATE,
PROTECTED,PUBLIC,READONLY,REF,RETURN,RIGHT_SHIFT,RIGHT_SHIFT_OPER,
SBYTE,SEALED,SHORT,SIZEOF,STACKALLOC,SUP,SUP_OR_EQ,STATIC,STRING,STRUCT,SWITCH,THIS,THROW,TRUE,
TRY,TYPEOF,UINT,ULONG,UNCHECKED,UNSAFE,UNSHORT,USING,VIRG,VIRTUAL,VOID,VOLATILE,VAL_NULL,WHILE,
XOR,XOR_OPER}typetoken;*/
#endif

typetoken lire_token();

//typedef enum{false=0,true=1}boolean;

boolean _modifier_access_1();
boolean _modifier_access_2();
boolean _modifier();

boolean _type();
boolean _return_type();
boolean _return_type_or_IDF();

boolean _param_list();
boolean _param();
boolean parametre_modifier();
boolean _param_list_aux();

boolean _liste_inst_aux(listinstvalueType ** pplistinstattribute);
boolean MET_DECL(listinstvalueType ** pplistinstattribute);
boolean _LIST_INST(listinstvalueType ** pplistinstattribute);
boolean _statement_block(listinstvalueType ** pplistinstattribute);
boolean LIST_MET_DECL();
boolean _statement(listinstvalueType ** pplistinstattribute);
boolean _if_inst_aux(listinstvalueType ** pplistinstattribute);
boolean _expression();
boolean _if_statement(listinstvalueType ** pplistinstattribute);
boolean _decl();
boolean _decl_aux();
boolean _INST(instvalueType ** ppinstattribute);

boolean _COND();
boolean _LIST_COND();
boolean _LIST_COND_AUX();


boolean terme();//zedtha
boolean print();//zedtha
boolean ecrire();//zedtha
boolean idff();//zedtha
boolean idff_aux();//zedtha

boolean _list_importation();
boolean _list_importation_aux();
boolean _using_clause();
boolean _quali();
boolean _idf_aux();

