#include<stdio.h>
#include<stdlib.h>
//#include "c_analyseur.h"
#include "c_list_meth.h"
#include<string.h>




info_param *tab_para=NULL;//stocker les param declarés //
MET_STOCK *list_methode=NULL;//stocker les caractéristique d'une méthode
int index_para=0;
int index_methode=0;
int index_var=0;
 

void cree_list_methode(){
	list_methode=(MET_STOCK *)malloc(100*sizeof(MET_STOCK));index_methode=0;
}


/*void stocker_methode(typetoken access_modif_1,typetoken access_modif_2,typetoken return_type_fct,char *nom_fct,int ligne_decl,int nbre_param){

	printf("la ligne :%d stocker methode %s\n",ligne_decl,nom_fct);
	
	list_methode[index_methode].access_modif_1=access_modif_1;
	list_methode[index_methode].access_modif_2=access_modif_2;
	list_methode[index_methode].return_type_fct=return_type_fct;
	strcpy((list_methode+index_methode)->nom_fct,nom_fct);
	list_methode[index_methode].ligne_decl=ligne_decl;
	list_methode[index_methode].nbre_param=nbre_param;
	//(list_methode+index_methode)->list_param_meth=tab_para;
	copier();
	index_methode++;
}*/

void stocker_methode(MET_STOCK meth,varvalueType *TS,int length){

	list_methode[index_methode].access_modif_1=meth.access_modif_1;
	list_methode[index_methode].access_modif_2=meth.access_modif_2;
	list_methode[index_methode].return_type_fct=meth.return_type_fct;
	strcpy((list_methode+index_methode)->nom_fct,meth.nom_fct);
	list_methode[index_methode].ligne_decl=meth.ligne_decl;
	list_methode[index_methode].nbre_param=meth.nbre_param;
	list_methode[index_methode].nbre_var=length;

	/*meth.pplistinstattribute== (listinstvalueType *) malloc(sizeof(listinstvalueType));
	meth.pplistinstattribute=pplistinstattribute;*/
	//(list_methode+index_methode)->list_param_meth=tab_para;
	copier_tab_par();if (false)printf("OK tab_par\n");
	copier_tab_var(TS,length);
	index_methode++;
	if (false)printf("la ligne :%d stocker methode %s\n",meth.ligne_decl,meth.nom_fct);
}



int exist_methode_duplicate(typetoken type,char *nom_fct){
	int i,j;
	for(i=0;i<index_methode;i++){
		int same_type=0;
		if(strcmp(nom_fct,(list_methode+i)->nom_fct)==0) {
			if(list_methode[i].return_type_fct!=type)	return 0;//detection de l'erreur
			else{
				if(list_methode[i].nbre_param==index_para){
					for(j=0;j<index_para;j++){
						if(list_methode[i].list_param_meth[j].type_variable==INT) if (false)printf("int\n");
						if(tab_para[j].type_variable==DOUBLE)	if (false)printf("double\n");
						if(list_methode[i].list_param_meth[j].type_variable==tab_para[j].type_variable)	{if (false)printf("same type\n");same_type++;}
					}
					if(same_type==index_para)	return 0;
				}
			}
		}			
	}
	return 1;
}



int var_exist(char *nom_var,int ligne){//ajouter l'erreur :variable deja declaré
	int i;
	for(i=0;i<index_para;i++){
	if(strcmp(nom_var,(tab_para+i)->nom_variable)==0) {if (true)printf("ligne %d :variable %s existe deja\n",ligne,nom_var);return 0;}
	}
return 1;
}

/*void stocker_variable(char *nom_variable,typetoken type_variable,int ligne_decl,char *val_var,typetoken passage_variable){
	printf("la ligne :%d stocker variable %s %s\n",ligne_decl,nom_variable,val_var);
	strcpy((tab_para+index_para)->nom_variable,nom_variable);
	tab_para[index_para].type_variable=type_variable;
	tab_para[index_para].passage_variable=passage_variable;
	tab_para[index_para].ligne_decl=ligne_decl;
	//strcpy((tab_para+index_para)->val_var,val_var);
	index_para++;
}*/
void stocker_para(info_param para){
	//if (true)printf("la ligne :%d stocker variable %s\n",para.ligne_decl,para.nom_variable);
	strcpy((tab_para+index_para)->nom_variable,para.nom_variable);
	tab_para[index_para].type_variable=para.type_variable;
	tab_para[index_para].passage_variable=para.passage_variable;
	tab_para[index_para].ligne_decl=para.ligne_decl;
	//strcpy((tab_para+index_para)->val_var,val_var);
	index_para++;
}

int nombre_para(){
	return index_para;
}

void cree_tab_para(){
	tab_para=(info_param *)malloc(20*sizeof(info_param));
	index_para=0;
}

void free_tab_para(){
	free(tab_para);
	tab_para=NULL;
}

void afficher_meth(){
	int i;
	if (true)printf("les fonctions qui ont été déclaré: \n");
	for(i=0;i<index_methode;i++){
		printf("%s\n",(list_methode+i)->nom_fct);
	}
}

void copier_tab_par(){
	int i;
	for(i=0;i<index_para;i++){
		(list_methode+index_methode)->list_param_meth[i]=tab_para[i];
	}
}
void copier_tab_var(varvalueType *TS,int length){
	int i;
	for(i=0;i<length;i++){
		if (false)printf("hhhh\n");
		(list_methode+index_methode)->list_variable[i]=TS[i];
	}
	if (false)printf("SUCCESS\n");
} 

/*instvalueType* recuperer_methode(char *nomFct){
	int i=0;
	for(i=0;i<index_methode;i++){
		if(strcmp(nomFct,(list_methode+i)->nom_fct)==0)	{
			pseudocode pc = generer_pseudo_code(*pplistinstattribute);
			if (true) printf("Affichage du pseudocode généré :\n");
			afficher_pseudo_code(pc);
			return (list_methode+i)->pplistinstattribute;
		}
	}
	return NULL;
}
*/




