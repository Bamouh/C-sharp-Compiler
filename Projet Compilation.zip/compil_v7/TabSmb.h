#ifndef TABSMB_H
#define TABSMB_H

#include "Class.h"
#define N 10

typedef struct termeType termeType;
struct termeType{
	char terme1[20];
	char terme2[20];
	char nom[50];
	int ligne;
	int nbHeri;
	char type[20];
	termeType** herinter;
	int niveau;
	int nbClassesFilles;
	int okk;
	termeType** listeClassDecl;
	termeType* nextTerme;
};

typedef struct fileClass fileClass;
struct fileClass{
	termeType* firstTerme;
};

void creer_file_class();
void creer_class(char* terme1,char* terme2,char* nom,int ligne,char* type,int nbHeri,termeType** herinter,int niveau,int nbClassesFilles,termeType** listeClassDecl);
void ajouter_classes_filles(int niveau);
void afficher_class();
boolean rechercher_class(char* nom);
termeType* get_class(char* nom);

//Erreurs
boolean incorrectmodifier(char* nom);
boolean multipleheritageerror(char* nom);
boolean sameclassheritageerror(char* nom);
boolean sameinterfaceerror(char* nom);
boolean interfaceeredunduncyrror(char* nom);
boolean interfaceheriteclasse(char* nom);

boolean interfacedeclareclass(char* nom);
boolean classfilleestheritee(char* nom);


//need a function : non public classes can't be created inside a namespace

#endif
