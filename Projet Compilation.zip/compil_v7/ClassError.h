#ifndef CLASSERROR_H
#define CLASSERROR_H

#include "Class.h"
#include "TabSmb.h"

typedef enum{
CDD,IM,HE,IE,Other
}ErrorType;

//CDD : Classe dèja définie
//IM : Incorrect modifier
//HE : Heritage Error
//IE : Interface Error

typedef struct Error Error;
struct Error{
	char terme[20];
	int ligne;
	char comment[100];
	ErrorType type;
	Error* nextErr;
};

typedef struct fileErr fileErr;
struct fileErr{
	Error* firstErr;
};

void creer_file_erreur();
void creer_sm_erreur_class(ErrorType et,int ligne,char* name,char* comment);
int nombre_sm_erreurs_class();
void afficher_sm_erreurs();


#endif
