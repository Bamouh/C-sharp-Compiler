#ifndef CLASS_H
#define CLASS_H
#include "types.h"
#include "ast.h"
#define N 10

/*typedef enum{
NEW,egal,idf,CLASS,interface,pvirgule,virgule,deuxpoints,openBracket,closeBracket,PUBLIC,PROTECTED,internal,PRIVATE,abstract,sealed,STATIC
}typetoken;*/

/*typedef enum{
true,false
}boolean;*/

boolean LISTE_CLASS();
boolean LISTE_CLASS_AUX();
boolean CLASSE();
boolean CLASS_MODIFIER1();
boolean CLASS_MODIFIER2();
boolean CLASS_OR_INTERFACE();
boolean CLASS_BASE();
boolean CLASS_BODY();
boolean CLASS_INTHERI();
boolean CLASS_INTHERI_AUX();
boolean LISTE_DECL();
boolean METHOD();
typetoken lire_token();
boolean DECL_LIST();
boolean encap();
boolean all();

#endif
