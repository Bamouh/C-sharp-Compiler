#include<stdio.h>
#include<stdlib.h>
#include "Class.h"
#include "ClassError.h"
#include "TabSmb.h"
#include<string.h>

#include "c_analyseur.h"
#include "c_error_meth.h"
#include "c_list_meth.h"
#include "tablesymb.h"
#include "error.h"

#define N 10

extern int yylex();
extern char* yytext;
extern fileErr* file;
extern fileClass* file2;
extern int yylineno;
boolean importation=0;
int rangvar;

typetoken token;
boolean follow_token=false;

char* terme;
char* terme2;
char* nom;
int ligne=0;
char* type_class;
termeType** herinter;
termeType** listeClassDecl;
int c=0;
int niveau=0;
int maxNiveau=0;

typetoken type_return=VAL_NULL;
char nom_decl[100];
typetoken val_modifier1=VAL_NULL;
typetoken val_modifier2=VAL_NULL;

Type type_var;
boolean semanticerror = false;

//declarer une variable de type info_param
info_param para;

//variable pour stocker les methodes
MET_STOCK meth;
//variable tablesymb
varvalueType varattribute;
constvalueType constattribute;
typevalueType typeattribute;
instvalueType instattribute;
listinstvalueType listinstattribute;
tokenvalueType tokenattribute;

boolean _addsub(AST *past);
boolean _addsubaux(AST *past);
boolean _multdiv(AST *past);
boolean _multdivaux(AST *past);
boolean _aux(AST *past);

typetoken lire_token(){
	if(follow_token==true){
		follow_token=false;
		return token;
	}
	return (typetoken)yylex();
}

boolean LISTE_CLASS(){
	boolean result=false;
	if(CLASSE()==true){
		token=lire_token();
		result=LISTE_CLASS();
	}
	else if(token==ACC_FER){
		ajouter_classes_filles(maxNiveau);
		//printf("sdffssffds");
		termeType* tt=file2->firstTerme;
		
		while(tt->nextTerme!=NULL){
			if(interfacedeclareclass(tt->nom)==true){creer_sm_erreur_class(IE,ligne,tt->nom,"Une INTERFACE ne peut pas declarer une classe");}
			if(classfilleestheritee(tt->nom)==true){creer_sm_erreur_class(IE,ligne,tt->nom,"Une classe ne peut pas hériter/implementer une classe fille");}
			tt=tt->nextTerme;	
		}
		
		result=true;
	}
	else{
		result=false;
	}
	return result;
}

/*
boolean LISTE_CLASS_AUX(){
	boolean result=false;
	if(token==ACC_FER){
		follow_token=true;
		result=true;
	}
	else{
		result=LISTE_CLASS();
	}
	return result;
}
*/

boolean CLASSE(){
	boolean result=false;
	//printf("begin\n");
	if(CLASS_MODIFIER1()==(boolean)true){
		//printf("modi1\n");
		token=lire_token();
		if(CLASS_MODIFIER2()==true){
			//printf("modi2\n");
			token=lire_token();
			if(CLASS_OR_INTERFACE()==true){
				//printf("class/INTERFACE\n");
				token=lire_token();
				if(token==IDF){
					//printf("nameclass\n");
					strcpy(nom,yytext);
					token=lire_token();
					if(CLASS_BASE()==true){
						//printf("baseclass\n");
						token=lire_token();
						if(CLASS_BODY()==true){
							//printf("classbody\n");
							result=true;
						}
					}
				}
			}
		}
	}
	else{
		result=false;
	}
	return result;
}

boolean CLASS_MODIFIER1(){
	boolean result=(boolean)false;
	if(token==PUBLIC){
		result=(boolean)true;
		//printf("ayyy\n");
		strcpy(terme,yytext);
		//printf("good\n");
	}
	else if(token==PRIVATE){
		result=(boolean)true;
		strcpy(terme,yytext);
		//printf("good\n");
	}
	else if(token==PROTECTED){
		result=(boolean)true;
		strcpy(terme,yytext);
		//printf("good\n");
	}
	else if((token==INTERNAL)||(token==ABSTRACT)||(token==SEALED)||(token==STATIC)){
		result=true;
		strcpy(terme2,yytext);
		follow_token=true;
	}
	else if((token==CLASS)||(token==INTERFACE)){
		result=true;
		strcpy(type_class,yytext);
		follow_token=true;
	}
	else{
		result=(boolean)false;
		//printf("bad\n");
	}
	return (boolean)result;
}

boolean CLASS_MODIFIER2(){
	boolean result=false;
	
	if(token==(typetoken)INTERNAL){
		strcpy(terme2,yytext);
		result=true;
	}
	else if(token==(typetoken)ABSTRACT){
		strcpy(terme2,yytext);
		result=true;
	}
	else if(token==(typetoken)SEALED){
		strcpy(terme2,yytext);
		result=true;
	}
	else if(token==(typetoken)STATIC){
		strcpy(terme2,yytext);
		result=true;
	}
	else if((token==CLASS)||(token==INTERFACE)){
		result=true;
		follow_token=true;
		strcpy(type_class,yytext);
	}
	else{
		result=false;
	}
	return result;
}

boolean CLASS_OR_INTERFACE(){
	boolean result=false;
	if (token==(typetoken)CLASS){
		strcpy(type_class,yytext);
		result=true;
	}
	else if (token==(typetoken)INTERFACE){
		strcpy(type_class,yytext);
		result=true;
	}
	else{
		result=false;
	}
	return result;
}

boolean CLASS_BASE(){
	boolean result=false;
	if(token==(typetoken)DEUX_PT){
		//printf("DEUX_PT ok\n");
		token=lire_token();
		if(CLASS_INTHERI()==true){
			result=true;
		}
	}
	else if(token==ACC_OUVR){
		follow_token=true;
		result=true;
	}
	else{
		result=false;
	}
	return result;
}

boolean CLASS_INTHERI(){
	boolean result=false;
	if(token==IDF){
		strcpy(herinter[c]->nom,yytext);
		c++;
		token=lire_token();
		result=CLASS_INTHERI_AUX();
	}
	else{
		result=false;
	}
	return result;
}

boolean CLASS_INTHERI_AUX(){
	boolean result=false;
	if(token==(typetoken)ACC_OUVR){
		result=true;
		follow_token=true;
	}
	else if(token==VIRG){
		token=lire_token();
		result=CLASS_INTHERI();
	}
	else{
		result=false;
	}
	return result;
}

boolean CLASS_BODY(){
	boolean result=false;
	if(token==ACC_OUVR){
		niveau++;
		maxNiveau++;
		if(rechercher_class(nom)==true){creer_sm_erreur_class(CDD,ligne,nom,"");}
		else{
			//printf("Partie Classe terminée.\n");
			if(strcmp(terme,"")==0){strcpy(terme,"null");}
			if(strcmp(terme2,"")==0){strcpy(terme2,"null");}
			//printf("modi1: %s\nmodi2: %s\ntype: %s\nnom: %s\n",terme,terme2,type,nom);
			int h=0;
			//printf("Classes héritées/implémentées: %d\n",c);
			while(h<c){
				if(rechercher_class(herinter[h]->nom)==true){//Si la classe mère existe
					termeType* class = get_class(herinter[h]->nom);
					strcpy(herinter[h]->type,class->type);
					strcpy(herinter[h]->terme1,class->terme1);
					strcpy(herinter[h]->terme2,class->terme2);
					herinter[h]->ligne=ligne;
					herinter[h]->niveau=class->niveau;
					herinter[h]->nextTerme=NULL;
					herinter[h]->herinter=NULL;
				}
				else if(strcmp(herinter[h]->nom,nom)==0){//La classe mère est la classe qu'on veut déclarer (erreur)
					strcpy(herinter[h]->type,type_class);
					strcpy(herinter[h]->terme1,terme);
					strcpy(herinter[h]->terme2,terme2);
					herinter[h]->ligne=ligne;
					herinter[h]->niveau=niveau;
					herinter[h]->nextTerme=NULL;
					herinter[h]->herinter=NULL;
				}
				else{//Si la classe mère n'existe pas
					char* s;
					char* ss;
					ss=malloc(30*sizeof(char));
					s=malloc(30*sizeof(char));
					strcpy(ss,herinter[h]->nom);
					s=strcat(ss," n'existe pas");
					//("La classe %s n'existe pas\n",herinter[h]->nom);
					creer_sm_erreur_class(HE,ligne,nom,s);
				}
				h++;
			}
			/*
			while(h<c){
				printf("nom: %s\ntype: %s\nmodi1: %s\nmodi2: %s\n",herinter[h]->nom,herinter[h]->type,herinter[h]->terme1,herinter[h]->terme2);
				h++;
			}
			*/
			creer_class(terme,terme2,nom,ligne,type_class,c,herinter,niveau,0,listeClassDecl);
			
			c=0;
			if(false)printf("Classe créee.\n");
			if(incorrectmodifier(nom)==true){creer_sm_erreur_class(IM,ligne,nom,"");}
			if(multipleheritageerror(nom)==true){creer_sm_erreur_class(HE,ligne,nom,"Héritage multiple");}
			if(sameclassheritageerror(nom)==true){creer_sm_erreur_class(HE,ligne,nom,"Une classe ne peut pas hériter d'elle-meme");}
			if(sameinterfaceerror(nom)==true){creer_sm_erreur_class(IE,ligne,nom,"Une INTERFACE ne peut pas s'implementer elle-meme");}
			if(interfaceeredunduncyrror(nom)==true){creer_sm_erreur_class(IE,ligne,nom,"Une classe ne peut pas implementer plusieurs fois la meme classe");}
			if(interfaceheriteclasse(nom)==true){creer_sm_erreur_class(IE,ligne,nom,"Une INTERFACE ne peut pas heriter d'une classe");}
		}
		token=lire_token();
/*
		if(LISTE_CLASS()==true){
			token=lire_token();
			if(token==ACC_FER){
				niveau--;
				result=true;
			}
		}
*/
		if(DECL_LIST()){
			if(false)printf("DECL_LIST\n");
			token=lire_token();
			if(token==ACC_FER){
				niveau--;
				result=true;
			}
			else	result=false;
		}
		else	result=false;	

	}
	else{
		result=false;
	}	
	return result; 
}

//DECL_LIST---->(encap (DEC_VAR|DECL_AUX)|DECL_CLASSE) DECL_LIST|epsilon
boolean DECL_LIST(){
	boolean result;
	listinstvalueType ** pplistinstattribute = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	*pplistinstattribute = NULL;
	if(token==ACC_FER){
		follow_token=true;
		result=true;	
	}
	else if(CLASSE()){
		token=lire_token();
		result=DECL_LIST();
	}

	else if(encap()){
		token=lire_token();
		if(_decl_aux()||MET_DECL(pplistinstattribute)){
			token=lire_token();
			result=DECL_LIST();
		}
		else	result=false;
	}

	else	result=false;
}
//encap---->modifier return_type_or_idf idf
boolean encap(){
	boolean result;
	if(_modifier()){
		if(false)printf("modifier\n");
		if(false)printf("good1\n");
		token=lire_token();
		if(_return_type_or_IDF()){
			if(false)printf("good2\n");
			if(false)printf("return type\n");
			token=lire_token();
			if(token==IDF){
				if(false) printf("good3\n");
				strcpy(nom_decl,yytext);
				if(false)printf("idf\n");
				result=true;
			}
			else result=false;
		}
		else result=false;
	}
	else result=false;
	return result;
}

boolean METHOD(){
	boolean result;
	return true;
}

boolean LISTE_DECL(){
	boolean result;
	return true;
}

int main(int argc,char* argv){
	
	if(false)printf("Compilateur begin\n");
	creer_file_erreur();
	if(false)printf("File des Erreurs crée\n");
	creer_file_class();
	if(false)printf("File des Classes crée\n");
	

	//------initialisation des parametres de méthodes------//
	cree_tab_para();	cree_file_error();  cree_list_methode();
	creer_tab_TS();
	para.passage_variable=VAL_NULL;
	
	
	meth.access_modif_1=VAL_NULL;		meth.access_modif_2=VAL_NULL;	
	meth.return_type_fct=VAL_NULL;		meth.nbre_param=0;
	
	//---------------------//



	terme = malloc(20*sizeof(char));
	type_class = malloc(20*sizeof(char));
	terme2 = malloc(20*sizeof(char));
	nom = malloc(50*sizeof(char));
	herinter = malloc(N*sizeof(termeType*));
	int i=0;
	while(i<N){
		*(herinter + i) = malloc(sizeof(termeType));
		i++;
	}

	listeClassDecl = malloc(N*sizeof(termeType*));
	int ii=0;
	while(ii<N){
		*(listeClassDecl + ii) = malloc(sizeof(termeType));
		ii++;
	} 
	
	token=lire_token();

	if(all()==true){
		if(false)printf("Execution réussie.");
	}	
	else{
		printf("Erreurs syntaxiques.");afficher_sm_erreurs_class();
	}
	
	//afficher_class();
	
	return 0;
}





//------------------Methode-----------------------------------




//Règles des méthodes de c#
//MET_DECL-->MODIFIER (return_type|epsilon) IDF "(" param_list ")" Statement_block


//MODIFIER_ACCESS_1-->public|private|protected|internal
boolean _modifier_access_1(){
	boolean result;
	if(token==PUBLIC || token==PRIVATE || token==PROTECTED || token==INTERNAL)  	{result=true;val_modifier1=token;}
	else	result=false;
	return result;
}

//MODIFIER_ACCESS_2-->static|abstract
boolean _modifier_access_2(){
	boolean result;
	if(token==STATIC || token==ABSTRACT)  	{result=true;val_modifier2=token;}
	else	result=false;
	return result;
}


/*MODIFIER-->MODIFIER_ACCESS_2|MODIFIER_ACCESS_1 (EPSILON|MODIFIER_ACCESS_2)
	|EPSILON 			*/
boolean _modifier(){
	boolean result;
	if(_modifier_access_1()) {
		token=lire_token();
		if(_modifier_access_2())	{result=true;}
		else if (_return_type_or_IDF()) {result=true;follow_token=true;}//follow de MODIFIER est INT,DOUBLE,etc
		else				result=false;
	}
	else if(_modifier_access_2())		{result=true;}
	else if (_return_type_or_IDF()) 	{result=true;follow_token=true;}//follow de MODIFIER est INT,DOUBLE,etc
	else result=false;
	return result;
}



//return_type--->"void"|type 
boolean _return_type(){
	boolean result;
	if(token==VOID)	{result=true;type_return=token;}
	else if(_type()) {if(false)printf("mzn\n");result=true;}
	else	result=false;
	return result;
}



//_type--->"FLOAT"|"DOUBLE"...
boolean _type(){
	boolean result;
	if(token==FLOAT || token==DOUBLE || token==INT || token==STRING || token==BOOL){result=true;type_return=token;
		switch(token){
			case FLOAT: type_var=Float;break;
			case DOUBLE: type_var=Double;break;
			case INT: type_var=Int;break;
			case STRING: type_var=String;break;
			case BOOL: type_var=Bool;break;
			default:break;
		}	
	}
	else	{result=false;}
	return result;
}

//_return_type_or_constructor--->_return_type|epsilon
boolean _return_type_or_IDF(){
	//cette fonction va nous permettre de connaitre si on va continuer dans la syntaxe de la méthode	ou du constructeur
	boolean result;
	if(false)printf("hhhhhh\n");
	if(_return_type())	{result=true;}
	else if(token==IDF)	{result=true;follow_token=true;}//FOLLOW est IDF
	else			result=false;
	return result;
}


//param--->parametre_modifier type idf
boolean _param(){
	boolean result;
	if(parametre_modifier()){
			token=lire_token();
			if(_type()){
				token=lire_token();
				if(token==IDF)	{result=true;strcpy(para.nom_variable,yytext);}
				else	result=false;
			}
			else	result=false;
	}
	else result=false;
	return result;
}
//parametre_modifier---->OUT | REF
//			|EPSILON
boolean parametre_modifier(){
	boolean result;
	if(token==OUT || token==REF)	{result=true;para.passage_variable=token;}
	else if(_type())		{result=true;follow_token=true;}//FOLLOW 	
	else				result=false;
	return result;
}


//param_list-->epsilon|param param_list_aux
boolean _param_list(){
	boolean result;
	if(_param()){
		meth.nbre_param++;
		if(false)printf("good 41 %s\n",para.nom_variable);
		if(var_exist(para.nom_variable,yylineno)==1) {if(false)printf("good html\n");stocker_para(para);}
		else	cree_sm_error(PARAM_DEJA_DECL,yylineno,para.nom_variable);
		if(false)printf("good 42\n");
		token=lire_token();
		result=_param_list_aux();
	}
	else{
		if(token==PAR_FER)	result=true;//follow
		else	result=false;
	}
	return result;
}

//param_list_aux-->epsilon|"," param param_list_aux
boolean _param_list_aux(){
	boolean result;
	if(token==VIRG){
		token=lire_token();
		if(_param()){
			meth.nbre_param++;
			if(false)printf("good 41 %s\n",para.nom_variable);
			if(var_exist(para.nom_variable,yylineno)==1) {if(false)printf("good html\n");stocker_para	(para);}
			else	cree_sm_error(PARAM_DEJA_DECL,yylineno,para.nom_variable);
			if(false)printf("good 42\n");
			token=lire_token();
			result=_param_list_aux();
		}
		else	result=false;
	}
	else{
		if(token==PAR_FER)	result=true;
		else	result=false;
	}
	return result;
}
		

//MET_DECL-->MODIFIER return_type IDF "(" param_list ")" Statement_block
boolean MET_DECL(listinstvalueType ** pplistinstattribute){
	boolean result;
	/*if(_modifier()){
		if (false)printf("good1\n");
		token=lire_token();
		if(_return_type_or_IDF()){
			if (false)printf("good2\n");
			meth.return_type_fct=type_return;
			token=lire_token();
			if(token==IDF){
				if (false) printf("good3\n");
				strcpy(meth.nom_fct,yytext);
				token=lire_token();*/
				if(token==PAR_OUVR){
		
					meth.return_type_fct=type_return;
					strcpy(meth.nom_fct,nom_decl);
					meth.access_modif_1=val_modifier1;
					meth.access_modif_2=val_modifier2;
					meth.ligne_decl=yylineno;
			      								
					if(false) printf("good4\n");
					token=lire_token();
					if(_param_list()){
							if(false) printf("good5\n");
							token=lire_token();
							if(_statement_block(pplistinstattribute))	{
									if(false)printf("good6\n");
									if(exist_methode_duplicate(meth.return_type_fct,meth.nom_fct)==1) stocker_methode(meth,get_TS(),nombre_variables());
		else	cree_sm_error(DUPLICATE_METH,yylineno,meth.nom_fct);
		//if(strcmp("Main",meth.nom_fct)==0 && meth.access_modif_2==VAL_NULL) cree_sm_error(MET_MAIN_NN_STATIC,yylineno,meth.nom_fct);
		if (nombre_sm_erreurs() == 0 && nombre_erreur()==0){
			if(false) printf("0 erreurs sémantiques\n");
			if(false) afficherTS();
			
			if(false) printf("Affichage du Control Flow Graph produit :\n"); 				//afficher_list_inst(*pplistinstattribute);
			if(strcmp(meth.nom_fct,"Main")==0){
					
				if(false) printf("Generation du code ...\n");			
				pseudocode pc = generer_pseudo_code(*pplistinstattribute);
				if(false) printf("Affichage du pseudocode généré :\n");
				afficher_pseudo_code(pc);
				if (false) printf("valeur de x %lf\n",valinit(0));
			}
		}else{
			printf("%d erreurs sémantiques\n", nombre_sm_erreurs());
			afficher_sm_erreurs();
			afficher_erreur();
		}
		//afficherTS();
		meth.nbre_param=0;
		free_tab_para();
		cree_tab_para();
		para.passage_variable=VAL_NULL;		reinitialiserTS();		
		meth.access_modif_1=VAL_NULL;	 	meth.access_modif_2=VAL_NULL;
		meth.return_type_fct=VAL_NULL;		

									result=true;
							}									
							else	result=false;
					}
					else	result=false;
				}
				else	result=false;
	return result;
}
//DECL--->TYPE IDF DECL_AUX
boolean _decl(){
	boolean result;
	if(_type()){
		varattribute.typevar=type_var;
		token=lire_token();
		if(token==IDF){
			strcpy(varattribute.name,yytext);
			token=lire_token();
			if(_decl_aux())	result=true;
			else		result=false;
		}
		else	result=false;
	}
	else	result=false;
	return result;
}

//DECL_AUX-->';' | '=' (INUMBER|DNUMBER) ';'
boolean _decl_aux(){
	boolean result;
	if(token==PT_VIRGULE){
		if(varattribute.typevar==Int || varattribute.typevar==Float || varattribute.typevar==Double){

			varattribute.valinit=0;
			varattribute.initialisation=true;
		}
		else	varattribute.initialisation=false;
		
		varattribute.line=yylineno;
		result=true;
	}
	else if (token==AFFECTATION){
		token=lire_token();
		if(token==INUMBER || token==DNUMBER){
			varattribute.initialisation=true;
			varattribute.line=yylineno;
			if(token==INUMBER)	varattribute.valinit=(double)atoi(yytext);
			else			varattribute.valinit=(double)atof(yytext);
			token=lire_token();
			if(token==PT_VIRGULE)	result=true;
			else	result=false;
		}
		else	result=false;
	}
	
	else	result=false;
	return result;
}


//INST--->IF_STATEMENT|FOR_STATEMENT|LIST_DECL|.......
boolean _INST(instvalueType ** ppinstattribute){
	boolean result;
	if (false) printf("inst()\n");

	AST *past = (AST *) malloc(sizeof(AST)); // NEW
	(*past) = (AST) malloc(sizeof(struct Exp));
	listinstvalueType ** pplistthen = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	listinstvalueType ** pplistelse = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	listinstvalueType ** pplistfor = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	*pplistthen = NULL;
	*pplistelse = NULL;
	*pplistfor = NULL;

	* ppinstattribute = NULL;

	int localrangvar; constvalueType borneinfconstattribute, bornesupconstattribute, localconstattribute; varvalueType localvarattribute;
	if(_decl()){
		result=true;
		if(inTS(varattribute.name,&rangvar)){
			creer_sm_erreur_declaration(AlreadyDeclared, varattribute.line, varattribute.name);		
		}
		else	{if (false)printf("AJOUTER\n");ajouter_nouvelle_variable_a_TS(varattribute);}
	}
	else if (token == IDF){//J'entre dans l'affectation
		if (false)printf("AFFECTATION\n");
		strcpy(localvarattribute.name,yytext);	localvarattribute.line=yylineno;
		if (false)printf("AFFECTATION: nomdevariable(%s) ligne(%d)\n",localvarattribute.name,localvarattribute.line);
		// 1ere gestion erreur NotDeclared : l'IDF (lexp) peut ne pas avoir été déclaré
		if (inTS(localvarattribute.name, &localrangvar) == false){
					if (false) printf("%sn'y est pas\n ", localvarattribute.name); afficherTS();
					semanticerror = true ;
					creer_sm_erreur_instruction(NotDeclared, localvarattribute.line, localvarattribute.name);
		}
		token = lire_token();
		if (token == AFFECTATION){
			token = lire_token();
			if (token == TRUE){
				token = lire_token();
				if (token == PT_VIRGULE){
				     if (semanticerror != true){
				     	if (typevar(localrangvar) == Bool) {
						*past = creer_feuille_booleen(false);
						
						*ppinstattribute = creer_instruction_affectation(localrangvar, past);
					     }else{
						semanticerror = true ;
						// 2eme gestion erreur IncompatibleAssignType : l'affectation peut être mal typée
						creer_sm_erreur_instruction(IncompatibleAssignType, localvarattribute.line, localvarattribute.name);
					     }
				     }
				     result = true;
				}else{
					result =  false;
				}
			}else if (token == FALSE){
				token = lire_token();
				if (token == PT_VIRGULE){
				     if (semanticerror != true){
					     if (typevar(localrangvar) == Bool){
						*past = creer_feuille_booleen(false);
						*ppinstattribute = creer_instruction_affectation(localrangvar, past);
					     }else{
						semanticerror = true ;
						// 2eme gestion erreur IncompatibleAssignType : l'affectation peut être mal typée
						creer_sm_erreur_instruction(IncompatibleAssignType, localvarattribute.line, localvarattribute.name);
					     }
				     }
				     result = true;
				}else{
					result =  false;
				}
			}else if (_addsub(past)){
				// Ce traitement n'a de sens que si la variable a bien été déclarée !!			
				if (false)printf("**********localrangvar**%d\n",localrangvar);
				if ( (semanticerror != true) && (typevar(localrangvar) != type(*past)) ){ //Double/Int, Int/Double, Bool/Int, Bool/Double
					if (false) 
					printf("typelexp(%s) == %s\n",name(localrangvar),(typevar(localrangvar)==Int)?"Int":((typevar(localrangvar)==Double)?"Double":"Boolean"));
					if (false) printf("typerexp == %s\n",(type(*past)==Int)?"Int":((type(*past)==Double)?"Double":"Boolean"));
				     if ( (typevar(localrangvar) == Double) && (type(*past) == Int)){
					(*past)->typename = Double; // Casting implicit Double = (Double) Int
				     }else{
					semanticerror = true ;
					// 2eme gestion erreur IncompatibleAssignType : l'affectation peut être mal typée
					creer_sm_erreur_instruction(IncompatibleAssignType, localvarattribute.line, localvarattribute.name);
				     }
				}
				token = lire_token();
				if (token == PT_VIRGULE){
					// Ce traitement n'a de sens que si la variable a bien été déclarée !!
					if (semanticerror != true){
						*ppinstattribute = creer_instruction_affectation(localrangvar, past);if (false)printf("!!!!!!!!!!!INSTRUCTION CREE !!!!!!!!!!!!!!\n");}
					result = true;
				} else result = false;
			} else result = false;		
		} else result = false;
	}	
	//else if(_if_statement(pplistthen))	result=true;
	else if (token == IF){
		token = lire_token();
		if (token == PAR_OUVR){
			if(false)printf("PAR_OUVR De IF\n");
			token = lire_token();
			if (token == IDF){
				strcpy(localvarattribute.name,yytext);localvarattribute.line=yylineno;
				// 3eme gestion erreur NotDeclared : l'IDF (lexp) peut ne pas avoir été déclaré
				if (inTS(localvarattribute.name, &localrangvar) == false){
							semanticerror = true;		
							creer_sm_erreur_instruction(NotDeclared, localvarattribute.line, localvarattribute.name);
				}else semanticerror = false;
				token = lire_token();
				if (token == EQ){
					token = lire_token();
					if (_addsub(past)){
						// N'a vraiement de sens que s'il n'y pas d'erreur sémantique dans la déclaration du IDF
						if ( (semanticerror != true) && (typevar(localrangvar) != type(*past) ) ){ //Int/Double, Double/Int, Double/Bool, Bool/Double, Int/Bool, Bool/Int
							// 4eme gestion erreur IncompatibleCompType : la conditionnelle peut être mal typée
							if ((typevar(localrangvar) == Bool) || (type(*past) == Bool)){ // Double/Bool, Bool/Double, Int/Bool, Bool/Int
								semanticerror = true;
								creer_sm_erreur_instruction(IncompatibleCompType, localvarattribute.line, localvarattribute.name);
							}// else casting implicite pas besoin de faire de traitement !! pour Int/Double, Double/Int
						}
						token = lire_token();
						if (token == PAR_FER){
							token = lire_token();
							if (token == ACC_OUVR){
								token = lire_token();
								if(false)printf("IF entre dans list\n");
								if (_LIST_INST(pplistthen)){
									token = lire_token();
									if (_if_inst_aux(pplistelse) == true){

										// N'a de sens que s'il n'y pas d'erreur sémantique dans tout le IF !!
										if (semanticerror != true)
											*ppinstattribute = creer_instruction_if(localrangvar, past, *pplistthen, *pplistelse);
										//if (false) afficher_inst(**ppinstattribute);
										result = true;
									}else result = false;
								}else result = false;
							}else result = false;
						}else result = false;
					}else result = false;
				} else result = false;
			} else result = false;
		} else result = false;
	}	
	else if (token==CONCOLEWRITELINE){
			token=lire_token();
			if(token==PAR_OUVR){
				token=lire_token();
				if (token == IDF){
					strcpy(varattribute.name,yytext);varattribute.line=yylineno;
					if (inTS(varattribute.name, &rangvar) == false) {
					semanticerror = true ;
					creer_sm_erreur_instruction(NotDeclared, varattribute.line, varattribute.name);
					}else{

					if(importation==0)
							printf("erreur: vous n'avez pas importé System.Console");
					else{
						if (semanticerror != true) *ppinstattribute = creer_instruction_print(rangvar);
						}
					}
					token = lire_token();
					if(token==PAR_FER){
						token=lire_token();
						if (token == PT_VIRGULE) {
							/*if(imporation==0)
							printf("erreur: vous n'avez pas importé System.Console");*/
							result = true;
						}else result = false;
					}else result = false;
				}else result=false;
			}else result=false;				
	}
	else				result=false;
	return result;
}
//LIST_INST--->INST LIST_INST|EPSILON
boolean _LIST_INST(listinstvalueType ** pplistinstattribute){

	instvalueType ** ppinstattribute = (instvalueType **) malloc(sizeof(instvalueType *));
	*ppinstattribute = NULL;

	boolean result;
	if(token==ACC_FER){//follow de LIST_INST
			result=true;
			follow_token = true;
			* pplistinstattribute = NULL;
			if (false)printf("good411\n");
	}
	else if (_INST(ppinstattribute)) {
		// bugg !! les ast ne sont pas termines printf("new inst ===>");afficher_inst(**ppinstattribute);
		if (false)printf("FIN INST\n");
		token = lire_token();
		if (_liste_inst_aux(pplistinstattribute) == true){
			if (false)printf("FIN INST2\n");
			if (semanticerror != true && * ppinstattribute!=NULL) inserer_inst_en_tete(pplistinstattribute, **ppinstattribute);
			result = true;if (false)printf("BON\n");
		}	
		else {result = false;if (false)printf("MAUVAIS\n");}
	}
	else result = false;
	if (false)printf("FIN DE LIST_INST\n");
	return result;
}

boolean _liste_inst_aux(listinstvalueType ** pplistinstattribute){
        boolean result;
	if (false) printf("list_inst_aux()\n");

	if(token==ACC_FER){//follow de LIST_INST
		result=true;follow_token = true;
		* pplistinstattribute = NULL;
		if (false)printf("good4112\n");
	}
	else if (_LIST_INST(pplistinstattribute) == true){
		result = true;
	} 
	else result = false;

	if (false) printf("out of list_inst_aux()\n");	
	return result;
}
//Statement-->"{" LIST_INST "}"
boolean _statement(listinstvalueType ** pplistinstattribute){
	boolean result;
	if(token==ACC_OUVR){
			if (false)printf("good41\n");
			token=lire_token();
			if(_LIST_INST(pplistinstattribute)){if (false)printf("ATT\n");
				token=lire_token();
				if (false)printf("good42\n");
				if(token==ACC_FER)	result=true;
				else			result=false;
			}
			else			result=false;
			}
	else	result=false;
	return result;
	}


//Statement_block->statement|;
boolean _statement_block(listinstvalueType ** pplistinstattribute){
	boolean result;
	if(token==PT_VIRGULE)	result=true;
	else if(_statement(pplistinstattribute))	result=true;
	else			result=false;
	return result;
}


//LIST_MET_DECL-->EPSILON|MET_DECL LIST_MET_DECL
boolean LIST_MET_DECL(){
	boolean result;
	listinstvalueType ** pplistinstattribute = (listinstvalueType **) malloc (sizeof(listinstvalueType *));
	*pplistinstattribute = NULL;

	if(token==ACC_FER) result=true;//j'ai considéré que le follow est l'accolade fermante de la classe
	else if(MET_DECL(pplistinstattribute)){
		token=lire_token();
		result=LIST_MET_DECL(pplistinstattribute);
	}
	
	else 	result=false;
	return result;
}



//EXPRESSION--->true|false|.....A ajouter!!!!!!!!!!!!!!!
/*boolean _expression(){
	boolean result;
	if(token==FALSE || token==TRUE|| token==IDF)	result=true;
	//else if(_LIST_COND())	result=true;
	else	result=false;
	return result;
}

//LIST_COND---->COND LIST_COND_AUX
/*boolean _LIST_COND(){
	boolean result;
	if(_COND()){
		token=lire_token();
		result=_LIST_COND_AUX();
	}
	else	result=false;
	return result;
}
//COND--->IDF OP_ARITH ADDSUBAUX 
boolean _COND(){
	boolean result;
	if(token==IDF){
		strcpy(varattribute.name,yytext);	varattribute.line=yylineno;
		if (inTS(varattribute.name, &rangvar) == false) {
			semanticerror = true;
			creer_sm_erreur_instruction(NotDeclared, varattribute.line, varattribute.name);//Dans ce test je veux savoir si cette a été deja declaré vu que j'ai trouvé un IDF pour cela j'utilise la fonction inTs() définit sur tablesymb.c, si la variable n'a pas été déclaré j'invoque la fonction creer_sm_error definit sur error.c Ce genre de condition on l'utilise très souvent dans le code
		
		}
		token=lire_token();
		if(token==EQ || token==NOT_EQ || token==SUP || token==INF || token==INF_OR_EQ || token==SUP_OR_EQ){
			token=lire_token();
			if(_aux())	result=true;
			else			result=false;
		}
		else result=false;
	}
	else result=false;
	return result;
}

//LIST_COND_AUX----->EPSILON | OP_LOGIQUE LIST_COND
boolean _LIST_COND_AUX(){
	boolean result;
	if(token==PAR_FER){
		follow_token=true;
		result=true;
	}
	else if(token==AND || token==OR){
		token=lire_token();
		result=_LIST_COND();
	}
	else	result=false;
	return result;
}*/
//IF_STATEMENT--->"if" "(" idf==addsubaux ")" STATEMENT IF_INST_AUX
/*boolean _if_statement(listinstvalueType ** pplistinstattribute){
	boolean result;
	if (token == IF){
		token = _lire_token();
		if (token == PAR_OUVR){
			token = lire_token();
			if (token == IDF){
				
				strcpy(localvarattribute.name,yytext); localvarattribute.line=line;
				// 3eme gestion erreur NotDeclared : l'IDF (lexp) peut ne pas avoir été déclaré
				if (inTS(localvarattribute.name, &localrangvar) == false){
							semanticerror = true;		
							creer_sm_erreur_instruction(NotDeclared, localvarattribute.line, localvarattribute.name);
				}else semanticerror = false;
				token = _lire_token();
				if (token == EQ){
					token = _lire_token();
					if (_addsub(past)){
						// N'a vraiement de sens que s'il n'y pas d'erreur sémantique dans la déclaration du IDF
						if ( (semanticerror != true) && (typevar(localrangvar) != type(*past) ) ){ //Int/Double, Double/Int, Double/Bool, Bool/Double, Int/Bool, Bool/Int
							// 4eme gestion erreur IncompatibleCompType : la conditionnelle peut être mal typée
							if ((typevar(localrangvar) == Bool) || (type(*past) == Bool)){ // Double/Bool, Bool/Double, Int/Bool, Bool/Int
								semanticerror = true;
								creer_sm_erreur_instruction(IncompatibleCompType, localvarattribute.line, localvarattribute.name);
							}// else casting implicite pas besoin de faire de traitement !! pour Int/Double, Double/Int
						}
						token = lire_token();
						if (token == PAR_FER){
							token = lire_token();
							if (token == ACC_OUVR){
								token = lire_token();
								if (_LIST_INST(pplistthen)){
									token = lire_token();
									if (_if_inst_aux(pplistelse) == true){

										// N'a de sens que s'il n'y pas d'erreur sémantique dans tout le IF !!
										if (semanticerror != true)
											*ppinstattribute = creer_instruction_if(localrangvar, past, *pplistthen, *pplistelse);
										//if (false) afficher_inst(**ppinstattribute);
										result = true;
									}else result = false;
								}else result = false;
							}else result = false;
						}else result = false;
					}else result = false;
				} else result = false;
			} else result = false;
		} else result = false;
	}
	else	result=false;
	return result;
}*/

//IF_INSTAUX---->EPSILON| "else" STATEMENT
/*boolean _if_inst_aux(listinstvalueType ** pplistinstattribute){
	boolean result;
	if(token==ELSE){
		if (false)printf("good51\n");
		token=lire_token();
		if(_statement(pplistinstattribute))	result=true;
		else			result=false;
	}
	else if(_LIST_INST(pplistinstattribute))	{result=true;follow_token=true;}
	else			result=false;
	return result;
}*/

// IF_INSTAUX :  endif | else LISTE_INST endif
boolean _if_inst_aux(listinstvalueType ** pplistinstattribute){
	boolean result;
	if (false) printf("if_inst_aux()\n");

	* pplistinstattribute = NULL;

	if (token == ACC_FER){
		result = true;
	}else if (token == ELSE){
		token = lire_token();
		if (_LIST_INST(pplistinstattribute) == true){
			token = lire_token();
			result = (token == ELSE);
		} else result = false;
	} else result = false;


	if (false) printf("out of if_inst_aux()\n");
	return result;
}

/*int main(){
	yyin=fopen("tester.txt","r");

	cree_tab_para();	cree_file_error();  cree_list_methode();
	creer_tab_TS();
	para.passage_variable=VAL_NULL;
	
	
	meth.access_modif_1=VAL_NULL;		meth.access_modif_2=VAL_NULL;	
	meth.return_type_fct=VAL_NULL;		meth.nbre_param=0;

	token=lire_token();
	if(LIST_MET_DECL())	if(false)printf("\n\ntest reussi\n");
	//if(ecrire())	printf("\ntest reussi\n");
	else		if(false)printf("echec\n");
	//afficher_meth();
	//afficher_erreur();
	return 0;
}*/

// ADDSUB : MULTDIV ADDSUBAUX
// erronée : produit un arbre dégénéré droit (associativité droite aulieu de gauche)
// correction :
// reçoit un arbre [past] en paramètre avec un arbre droit NULL
// lui installe l'arbre reçu de Multidiv comme arbre droit
// le repasse à ADDSUBaux en paramètre
boolean _addsub(AST *past){
	boolean result;
	if (false) printf("addsub()\n");

	AST *past1 = (AST *) malloc(sizeof(AST));
	AST *past2 = (AST *) malloc(sizeof(AST));

	(*past1) = (AST) malloc (sizeof(struct Exp)); // NEW 
        // NEW 9 : past a un arbre droit NULL
	if (_multdiv(past1)){
		token = lire_token();

		if ((*past)->noeud.op.expression_gauche == NULL) (*past) = *past1; // initialisation par le première feuille gauche. // NEW 10.1
		else (*past)->noeud.op.expression_droite = *past1; // NEW 10.2

		if (_addsubaux(past) == true){ 
		// if (_addsubaux(past2) == true){ // OLD 11
			/* OLD 12 if ( (*past1 != NULL) && (*past2 != NULL) ){
				char op = ((top(*past2)==plus)?'+':((top(*past2)==moins)?'-':((top(*past2)==mult)?'*':'/')));
				if (false) printf("--------->type(*past1) ==%s\n",(type(*past1)==Int)?"Int":(type(*past1)==Double)?"Double":"Bool");
				if (false) printf("--------->type(arbre_droit(*past2)) ==%s\n",(type(arbre_droit(*past2))==Int)?"Int":(type(arbre_droit(*past2))==Double)?"Double":"Bool");
				

					if ( (type(*past1) == type(arbre_droit(*past2))) ){ //Int/Int ou Double/Double
						*past = creer_noeud_operation(op, *past1, arbre_droit(*past2), type(*past1)); // 1ere inférence de type d'arbre arithmétique
					} else{ 
						*past = creer_noeud_operation(op, *past1, arbre_droit(*past2), Double); // casting implicite Int[+,-,*,/]Double ou Double[+,-,*,/]Int ==> Double
					}		
				}*/
				if ((arbre_droit(*past) != NULL) && (arbre_gauche(*past) != NULL)) {
					if (type(arbre_gauche(*past)) == type(arbre_droit(*past))){ // NEW 5 & 6 Int/Int ou Double/Double
						(*past)->typename = type(arbre_gauche(*past));
					}else (*past)->typename = Double;
				}else {(*past) = *past1;} // ??

				/* if (type(arbre_gauche(*past)) == type(arbre_droit(*past))){ // NEW 11 Int/Int ou Double/Double
					(*past)->typename = type(arbre_gauche(*past));
				}else (*past)->typename = Double; */
			// OLD 12 }else *past = *past1;
			result = true;
		}else result = false;
	}else result = false;

	if (false) printf("out of addsub()\n");
	return result;
}

// ADDSUBAUX : + MULTDIV ADDSUBAUX | - MULTDIV ADDSUBAUX | epsilon
// eq à (ADDSUBAUX : + ADDSUB | - ADDSUB | epsilon)
// erronée : produit un arbre dégénéré droit (associativité droite aulieu de gauche)
// correction :
// reçoit un arbre [past] en paramètre
// crée un nouvel arbre [newpast] dont il place la racine [+ ou -], place [past] à sa gauche avec un arbre droit NULL
// le repasse à ADDSUB en paramètre
// NULLABLE(ADDSUBAUX) = true
// follow(ADDSUBAUX) = { ';' , ')' }
// first(ADDSUBAUX) = { '-' , '+' }
boolean _addsubaux(AST *past){
	boolean result;
	if (false) printf("addsubaux()\n");

	// *past = NULL; OLDI

	// AST *past1 = (AST *) malloc(sizeof(AST)); ??

	if ( (token == PT_VIRGULE) || (token == PAR_FER) ){
		follow_token = true;
		result = true;
	}else if (token == ADDI) {
			token = lire_token();
			*past = creer_noeud_operation('+', *past, NULL, type(*past)); // NEW 1 : 2eme inférence de type d'arbre arithmétique
			if (_addsub(past) == true){
			// if (_addsub(past1) == true){
				//if (*past1 != NULL)
					//*past = creer_noeud_operation('+', NULL, *past1, type(*past1)); // OLD 1 2eme inférence de type d'arbre arithmétique
				result = true;
			}else result = false;
	} else if (token == MINUS) {
			token = lire_token();
			*past = creer_noeud_operation('-', *past, NULL, type(*past)); // NEW 2 : 2eme inférence de type d'arbre arithmétique
			if (_addsub(past) == true){
			//if (_addsub(past1) == true){
				// if (*past1 != NULL)
					// *past = creer_noeud_operation('-', NULL, *past1, type(*past1)); // OLD 2 3eme inférence de type d'arbre arithmétique
				result = true;
			}else result = false;
	} else result = false;

	if (false) printf("out of addsubaux()\n");
	return result;
}

// MULTDIV : AUX MULTAUX
// erronée : produit un arbre dégénéré droit (associativité droite aulieu de gauche)
// correction :
// reçoit un arbre [past] en paramètre avec un arbre droit NULL
// lui installe l'arbre reçu de Aux comme arbre droit
// le repasse à Multdivaux en paramètre
boolean _multdiv(AST *past){
	boolean result;
	if (false) printf("mult()\n");

	// *past = NULL; OLDI

	AST *past1 = (AST *) malloc(sizeof(AST));
	AST *past2 = (AST *) malloc(sizeof(AST));

        // NEW 3 : past a un arbre droit NULL
	(*past1) = (AST) malloc (sizeof(struct Exp)); // NEW 

	if (_aux(past1)){
		token = lire_token();
		//if ((*past1) == NULL) printf("PAST1 \n"); // NEW
		//if ((*past) == NULL) printf("PAST\n"); // NEW
		if ((*past)->noeud.op.expression_gauche == NULL) (*past) = *past1; // initialisation par le première feuille gauche.
		else (*past)->noeud.op.expression_droite = *past1; // NEW 3
		//if (arbre_gauche(*past) == NULL) printf("ag(PAST) 1\n"); // NEW
		//if (arbre_droit(*past) == NULL) printf("ad(PAST) 1\n"); // NEW
		if (_multdivaux(past) == true){ // NEW 4
		// if (_multdivaux(past2) == true){ // OLD 4
			/* OLD 5 if ( (*past1 != NULL) && (*past2 != NULL) ){ 
				char op = ((top(*past2)==plus)?'+':((top(*past2)==moins)?'-':((top(*past2)==mult)?'*':'/')));
				if (type(*past1) == type(arbre_droit(*past2))){ //Int/Int ou Double/Double
					*past = creer_noeud_operation(op, *past1, arbre_droit(*past2), type(*past1)); // 4eme inférence de type
				} else {
					*past = creer_noeud_operation(op, *past1, arbre_droit(*past2), Double); // casting implicite Int[+,-,*,/]Double ou Double[+,-,*,/]Int ==> Double
				}*/
				// if (arbre_gauche(*past) == NULL) printf("ag(PAST) 2\n"); // NEW
				if ((arbre_droit(*past) != NULL) && (arbre_gauche(*past) != NULL)) {
					if (type(arbre_gauche(*past)) == type(arbre_droit(*past))){ // NEW 5 & 6 Int/Int ou Double/Double
						(*past)->typename = type(arbre_gauche(*past));
					}else (*past)->typename = Double;
				}else {(*past) = *past1;} // ??
			// OLD 6 }else *past = *past1;
			result = true;
		}else result = false;
	}else result = false;

	if (false) printf("out of mult()\n");
	return result;
}

// MULTDIVAUX : * AUX MULTDIVAUX | / AUX MULTDIVAUX | epsilon
// eq à (MULTDIVAUX : * MULTDIV | / MULTDIV | epsilon)
// NULLABLE(MULTDIVAUX) = true
// follow(MULTDIVAUX) = { '+' , '-' , ';' , ')' }
// first(MULTDIVAUX) = { '*', '/' }
// erronée : produit un arbre dégénéré droit (associativité droite aulieu de gauche)
// correction :
// reçoit un arbre [past] en paramètre
// crée un nouvel arbre [newpast] dont il place la racine [/ ou *], place [past] à sa gauche avec un arbre droit NULL
// le repasse à MultDiv en paramètre
boolean _multdivaux(AST *past){
	boolean result;
	if (false) printf("multaux()\n");

	// *past = NULL; OLDI

	// AST *past1 = (AST *) malloc(sizeof(AST));
	
	if ( (token == ADDI) || (token == MINUS) || (token == PT_VIRGULE) || (token == PAR_FER) ){
		follow_token = true;
		result = true;
	}else if (token == MUL) {
			token = lire_token();
			*past = creer_noeud_operation('*', *past, NULL, type(*past)); // NEW 7 : 2eme inférence de type d'arbre arithmétique
			if (_multdiv(past)){
			// if (_multdiv(past)){
				//if ( (*past1 != NULL) )
					//*past = creer_noeud_operation('*', NULL, *past1, type(*past1)); //OLD 7 5eme inférence de type d'arbre arithmétique
				result = true;
			}else result = false;
	} else if (token == DIV) {
			token = lire_token();
			*past = creer_noeud_operation('/', *past, NULL, type(*past)); // NEW 8 : 2eme inférence de type d'arbre arithmétique
			if (_multdiv(past)){
			// if (_multdiv(past1)){
				// if ( (*past1 != NULL) )
					// *past = creer_noeud_operation('/', NULL, *past1, type(*past1)); //OLD 8 6eme inférence de type d'arbre arithmétique
				result = true;			
			}else result = false;
	} else result = false;

	if (false) printf("out of multaux()\n");
	return result;
}

// AUX : idf | number | ( ADDSUB ) ==> AUX : idf | inumber | dnumber | ( ADDSUB ) 
boolean _aux(AST *past){
	boolean result;

	// *past = NULL; OLDI

	if (false) printf("aux()\n");

	if  (token == IDF) {
		strcpy(varattribute.name,yytext); varattribute.line=yylineno;
		// 7eme gestion erreur NotDeclared : l'IDF peut ne pas avoir été déclaré
		if (inTS(varattribute.name, &rangvar) == false) {
			semanticerror = true;
			creer_sm_erreur_instruction(NotDeclared, varattribute.line, varattribute.name);
		
		// 8eme gestion erreur IncompatibleOperationType : l'IDF peut avoir été déclaré d'un type non entier ni double
		}else if ( (typevar(rangvar) != Int) && (typevar(rangvar) != Double) ) { // (si l'IDF est un Bool)
			semanticerror = true;
			creer_sm_erreur_instruction(IncompatibleOperationType, varattribute.line, varattribute.name);
		}else{
			// l'IDF est Int ou Double
			*past = creer_feuille_idf(name(rangvar), typevar(rangvar)); // On ne peut pas donc avoir un AST de type Bool (meme si l'IDF est un Bool)
		}
		result = true;
	} else if (token == INUMBER) {
		//printf("CONSTATTRIBUTE-------->%f\n",constattribute.valinit);
		if (false)printf("CONSTATTRIBUTE-------->%f\n",(double)atoi(yytext));
		//*past = creer_feuille_nombre(constattribute.valinit, Int);
		*past = creer_feuille_nombre((double)atoi(yytext), Int);
		result = true;
	} else if (token == DNUMBER) {
		if (false)printf("CONSTATTRIBUTE-------->%f\n",(double)atoi(yytext));
		*past = creer_feuille_nombre((double)atof(yytext), Double);
		result = true;
	}  else if (token == PAR_OUVR) {
		token = lire_token();
		if (_addsub(past)){
			token = lire_token();
			result = (token == PAR_FER);
		}else result = false;
	} else result = false;


	if (false) printf("out of aux()\n");
	return result;
}




boolean ecrire(){
	boolean result=false;
	if(token==CONCOLEWRITELINE){
		token=lire_token();
		if(token==PAR_OUVR){
			token=lire_token();
			if(print()){
				token=lire_token();
				if(token==PAR_FER){
					token=lire_token();
					if(token==PT_VIRGULE){
						if(importation==0)
							printf("vous n'avez pas importer System.Console\n");

					result=true;
					}
				}
			}
		}
	}
return result;
}

boolean print(){//Print=Idff idff_aux
boolean result=false;
if(idff()){
	token=lire_token();
	if(idff_aux()){
		result=true;
	}
}

return result;

}


boolean idff(){//Idff="idf"| idf
boolean result=false;
if(token==APP){
	token=lire_token();
	
		if(token==IDF){
			token=lire_token();
			if(token==APP){
			result=true;
			}
		}
	
}
else if (token==IDF){
	result=true;
}
return result;
}

//Idff_aux=+ print|eps
boolean idff_aux(){
boolean result=false;	
if(token==PAR_FER){
	follow_token = true;
	result=true;
}
else
if(token==ADD){
	token=lire_token();
	if(print()){
		result=true;
	}
}
return result;
}


boolean terme_affich(){//zedtha boolean 
boolean result=false;
	if(token==SYSTEM||token==IN||token==LINQ||token==NET){
	result=true;}
	else if(token==CONSOLE) {
	importation=1;
	result=true;
	}
return result;

}


//using_clause: "using" idf idf_aux quali ";"

boolean _using_clause(){
	boolean result;
	if(token==USING){
		token=lire_token();
		if(terme_affich()){//zedtha
			token=lire_token();
			if(_idf_aux()){
				token=lire_token();
				if(_quali()){
					token=lire_token();
					if(token==PT_VIRGULE){
						result=true;
					}
					else result=false ;
				}
				else result=false ;
			}
			else result=false ;
		}
		else result=false ;
	}
	else result=false ;
	return result;
}


// list_importation : using_clause list_importation_aux | eps
boolean _list_importation(){
	boolean result;
	if(_using_clause()){
		token=lire_token();
		if(_list_importation_aux()){
			result=true;
		}
		else result=false ;
	}
	else if(token==NAMESPACE)
		{
			follow_token = true;
			result=true;
		}
	else result=false ;
	return result;
}

//idf_aux: eps |"="idf 
boolean _idf_aux(){
	boolean result;
	if(token==AFFECTATION){
		token=lire_token();
		if(token==IDF){
			result=true;
		}
		else result=false ;
	}
	else if((token==POINT)||(token==PT_VIRGULE))
		{
			follow_token = true;
			result=true;
		}
	else result=false ;
	return result;
}
// quali= eps|"."IDF quali
boolean _quali(){
	boolean result;
	if(token==POINT){
		token=lire_token();
		if(terme_affich()){
			token=lire_token();
			if(_quali()){
				result=true;
			}
			else result=false ;
		}
		else result=false ;
	}
	else if(token==PT_VIRGULE)
		{
			follow_token = true;
			result=true;
		}
	else result=false ;
	return result;
}
//list_importation_aux: list_importation | eps
boolean _list_importation_aux(){
	boolean result;
	if(_list_importation()){
			result=true;
	}
	else if(token==NAMESPACE)
		{
			follow_token = true;
			result=true;
		}
	else result=false ;
	return result;
}


// all:_list_importation namespace idf "{"list_prog"}"
boolean all(){
	boolean result=false;
	if(_list_importation()){
		token = lire_token();
		if(token==NAMESPACE){
			token = lire_token();
			if(token==IDF){
				token = lire_token();
				if(token==ACC_OUVR){
					token = lire_token();
					if (LISTE_CLASS()) {
						result=true ;
					}
				}
			}
		}
	}
	return result;
}


