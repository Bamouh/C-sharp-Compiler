#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "Class.h"
#include "ClassError.h"
#include "TabSmb.h"
#include<string.h>
#define N 10

fileClass* file2;

void creer_file_class(){
	termeType* tt = malloc(sizeof(termeType));
	strcpy(tt->terme1,"public");
	strcpy(tt->terme2,"null");
	strcpy(tt->nom,"Object");
	tt->ligne=0;
	tt->nbHeri=0;
	strcpy(tt->type,"class");
	int i=0;
	tt->herinter=malloc(N*sizeof(termeType*));
	while(i<N){
		tt->herinter[i]=malloc(sizeof(termeType));
		i++;
	}
	i=0;
	tt->listeClassDecl=malloc(N*sizeof(termeType*));
	while(i<N){
		tt->listeClassDecl[i]=malloc(sizeof(termeType));
		i++;
	}
	tt->nextTerme=NULL;
	file2 = malloc(sizeof(fileClass));
	file2->firstTerme=tt;
}

void creer_class(char* terme1,char* terme2,char* nom,int ligne,char* type,int nbHeri,termeType** herinter,int niveau,int nbClassesFilles,termeType** listeClassDecl){
	termeType* v = malloc(sizeof(termeType));
	v->herinter=malloc(N*sizeof(termeType*));
	int a=0;
	while(a<N){
		v->herinter[a]=malloc(sizeof(termeType));
		a++;
	}
	int b=0;
	v->listeClassDecl=malloc(N*sizeof(termeType*));
	while(b<N){
		v->listeClassDecl[b]=malloc(sizeof(termeType));
		b++;
	}
	//printf("1");
	strcpy(v->terme1,terme1);
	//printf("2");
	strcpy(v->terme2,terme2);
	//printf("3");
	strcpy(v->nom,nom);
	//printf("4");
	v->ligne=ligne;
	//printf("5");
	strcpy(v->type,type);
	v->nbHeri=nbHeri;
	v->niveau=niveau;
	v->nbClassesFilles=nbClassesFilles;
	v->okk=1;
	int i=0;
	while(i<N){
		strcpy(v->herinter[i]->terme1,herinter[i]->terme1);
		strcpy(v->herinter[i]->terme2,herinter[i]->terme2);
		strcpy(v->herinter[i]->nom,herinter[i]->nom);
		v->herinter[i]->niveau=herinter[i]->niveau;
		strcpy(v->herinter[i]->type,herinter[i]->type);
		i++;
	}
	i=0;
	while(i<N){
		strcpy(v->listeClassDecl[i]->terme1,listeClassDecl[i]->terme1);
		strcpy(v->listeClassDecl[i]->terme2,listeClassDecl[i]->terme2);
		strcpy(v->listeClassDecl[i]->nom,listeClassDecl[i]->nom);
		strcpy(v->listeClassDecl[i]->type,listeClassDecl[i]->type);
		i++;
	}
	v->nextTerme=file2->firstTerme;
	file2->firstTerme=v;
}

void ajouter_classes_filles(int niveau){
	int compteur=0;
	termeType* classe=file2->firstTerme;
	while(classe->nextTerme!=NULL){
		compteur++;
		classe=classe->nextTerme;
	}
	
	int jj=0;
	char noms[compteur][50];
	for(jj=0;jj<compteur;jj++){
		int k=0;
		termeType* clas=file2->firstTerme;
		while((clas->nextTerme!=NULL)&&(k<compteur-jj-1)){
			clas=clas->nextTerme;
			k++;
		}
		strcpy(noms[jj],clas->nom);
	}
	
	int a=0;
	for(a=0;a<compteur;a++){
		if(false)printf("%s\n",noms[a]);
	}
	//printf("\nddddddddddddddddddddd\n");
	int i=0;
	int j=i;
	for(i=0;i<compteur-1;i++){
		//printf("go\n");
		termeType* classemere = get_class(noms[i]);
		j=i+1;
		termeType* classefille = get_class(noms[j]);
		//printf("%d---%d\n",classefille->niveau,classemere->niveau);
		int cco=0;
		while(classefille->niveau>classemere->niveau){
			//printf("gooo\n");
			strcpy(classemere->listeClassDecl[cco]->nom,classefille->nom);
			strcpy(classemere->listeClassDecl[cco]->type,classefille->type);
			strcpy(classemere->listeClassDecl[cco]->terme1,classefille->terme1);
			strcpy(classemere->listeClassDecl[cco]->terme2,classefille->terme2);
			classemere->listeClassDecl[cco]->ligne=classefille->ligne;
			classemere->listeClassDecl[cco]->nextTerme=NULL;
			classemere->listeClassDecl[cco]->herinter=NULL;
			j++;
			cco++;
			classefille = get_class(noms[j]);
		}	
		classemere->nbClassesFilles=cco;
	}
	
	/*
	int i=1;
	//printf("%d\n",niveau);
	
	for(i=1;i<niveau;i++){
		termeType* claas=file2->firstTerme;
		while(claas->nextTerme!=NULL){
			claas->okk=1;
			claas=claas->nextTerme;
		}
		//printf("%d\n",i);
		int n=0;
		while(n<compteur){
			termeType* classemere=get_class(noms[n]);
			int c=0;
			//printf("%d et %d\n",classemere->niveau,i);
			if(classemere->niveau==i){
				//printf("found\n");
				int m=0;
				while(m<compteur){
					termeType* classefille = get_class(noms[m]);
					if((classefille->niveau==i+1)&&(classefille->okk==1)){
						if(c>0){
							termeType* classPred = get_class(noms[m-1]);
							if(classPred->niveau==classefille->niveau){
								strcpy(classemere->listeClassDecl[c]->nom,classefille->nom);
								strcpy(classemere->listeClassDecl[c]->type,classefille->type);
								strcpy(classemere->listeClassDecl[c]->terme1,classefille->terme1);
								strcpy(classemere->listeClassDecl[c]->terme2,classefille->terme2);
								classemere->listeClassDecl[c]->ligne=classefille->ligne;
								classemere->listeClassDecl[c]->nextTerme=NULL;
								classemere->listeClassDecl[c]->herinter=NULL;
								classefille->okk=0;
								c++;
							}
						}
						else{
							strcpy(classemere->listeClassDecl[c]->nom,classefille->nom);
							strcpy(classemere->listeClassDecl[c]->type,classefille->type);
							strcpy(classemere->listeClassDecl[c]->terme1,classefille->terme1);
							strcpy(classemere->listeClassDecl[c]->terme2,classefille->terme2);
							classemere->listeClassDecl[c]->ligne=classefille->ligne;
							classemere->listeClassDecl[c]->nextTerme=NULL;
							classemere->listeClassDecl[c]->herinter=NULL;
							classefille->okk=0;
							c++;	
						}	
					}
					m++;
				}
				classemere->nbClassesFilles=c;
			}
			n++;
		}
	}
	*/
}

void afficher_class(){
	termeType* var=file2->firstTerme;
	if(file2->firstTerme==NULL){
		if(false)printf("Aucun terme détecté.");
	}
	else{
		if(false)printf("classes détectées\n");
	}
	while(var->nextTerme!=NULL){
		if(false)printf("\n\n\n");
		if(false)printf("modi1: %s\nmodi2: %s\ntype: %s\nnom: %s\n niveau: %d\n",var->terme1,var->terme2,var->type,var->nom,var->niveau);
		if(false)printf("Classes héritées/implémentées: %d\n",var->nbHeri);
		int h=0;
		while(h<(var->nbHeri)){
			if(false)printf("\tnom:%s\n\ttype:%s\n",var->herinter[h]->nom,var->herinter[h]->type);
			h++;
		}
		if(false)printf("Classes filles: %d\n",var->nbClassesFilles);
		int i=0;
		while(i<(var->nbClassesFilles)){
			if(false)printf("\tnom:%s\n\ttype:%s\n",var->listeClassDecl[i]->nom,var->listeClassDecl[i]->type);
			i++;
		}
		var=var->nextTerme;
	}
}

boolean rechercher_class(char* nom){
	char* nomm = malloc(20*sizeof(char));
	strcpy(nomm,nom);
	boolean result=false;
	termeType* var=file2->firstTerme;
	if(file2->firstTerme==NULL){
		if(false)printf("Aucune classe détectée.");
	}
	else{
		//printf("termes détectées\n");
		while(var->nextTerme!=NULL){
			//printf("%s ||| %s\n",var->nom,nomm);
			if(strcmp(var->nom,nomm)==0){
				//printf("trouvé");
				result=true;
				break;
			}
			var=var->nextTerme;
		}
	}
	return result;
}

termeType* get_class(char* nom){
	termeType* class=NULL;
	termeType* var=file2->firstTerme;
	while(var->nextTerme!=NULL){
		if(strcmp(var->nom,nom)==0){
			class=var;
			break;
		}
		var=var->nextTerme;
	}
	return class;
}

boolean incorrectmodifier(char* nom){
	boolean result=false;
	termeType* tt = file2->firstTerme;
	if(file2->firstTerme==NULL){
		if(false)printf("Aucune classe détectée");
	}
	else{
		while(tt->nextTerme!=NULL){
			if(strcmp(tt->nom,nom)==0){
				if((strcmp(tt->terme1,"null")!=0)&&(strcmp(tt->terme2,"null")!=0)){//public static class
					if(strcmp(tt->terme1,"public")==0){
						if(strcmp(tt->terme2,"internal")==0){
							result=true;
						}
					}
					
					if(strcmp(tt->terme1,"private")==0){
						result=true;//Must be outside namespace
					}
					if(strcmp(tt->terme1,"protected")==0){
						result=true;//Must be outside namespace
					}
					
				}
				else if((strcmp(tt->terme1,"null")!=0)&&(strcmp(tt->terme2,"null")==0)){//public class
					
					if(strcmp(tt->terme1,"private")==0){
						result=true;//Must be outside namespace
					}
					if(strcmp(tt->terme1,"protected")==0){
						result=true;//Must be outside namespace
					}
					
				}
				else if((strcmp(tt->terme1,"null")==0)&&(strcmp(tt->terme2,"null")!=0)){//static class
					
				}
				break;
			}
			tt=tt->nextTerme;
		}
	}
	return result;
}

boolean multipleheritageerror(char* nom){
	boolean result =false;
	int c=0;
	int i=0;
	termeType* tt = file2->firstTerme;
	while(tt->nextTerme!=NULL){
		if(strcmp(tt->nom,nom)==0){
			while(i<(tt->nbHeri)){
				if(strcmp(tt->herinter[i]->type,"class")==0){c++;}
				i++;
			}
			break;
		}
		tt=tt->nextTerme;
	}
	if(c>1){result=true;}
	//printf("NB CLASS HERITEES %d",c);
	return result;
}
boolean sameclassheritageerror(char* nom){
	boolean et=false;
	termeType* tt = file2->firstTerme;
	int i=0;
	while(tt->nextTerme!=NULL){
		if((strcmp(tt->nom,nom)==0)&&(strcmp(tt->type,"class")==0)){
			while(i<(tt->nbHeri)){
				if((strcmp(tt->herinter[i]->nom,nom)==0)&&(strcmp(tt->herinter[i]->type,"class")==0)){et=true;break;}
				i++;
			}
		break;
		}
		tt=tt->nextTerme;
	}
	return et;
}
boolean sameinterfaceerror(char* nom){
	boolean et=false;
	termeType* tt = file2->firstTerme;
	int i=0;
	int c=0;
	while(tt->nextTerme!=NULL){
		if((strcmp(tt->nom,nom)==0)&&(strcmp(tt->type,"interface")==0)){
			while(i<(tt->nbHeri)){
				if((strcmp(tt->herinter[i]->nom,nom)==0)&&(strcmp(tt->herinter[i]->type,"interface")==0)){et=true;break;}
				i++;
			}
		break;
		}
		tt=tt->nextTerme;
	}
	return et;
}
boolean interfaceeredunduncyrror(char* nom){
	boolean et=false;
	termeType* tt = file2->firstTerme;
	int i=0;
	while(tt->nextTerme!=NULL){
		if(strcmp(tt->nom,nom)==0){
			while(i<(tt->nbHeri)){
				int j=0;
				while(j<(tt->nbHeri)){
					if((j!=i)&&(strcmp(tt->herinter[i]->nom,tt->herinter[j]->nom)==0)){et=true;}
					j++;
				}
				i++;
			}
			break;
		}
		tt=tt->nextTerme;
	}
	return et;
}

boolean interfaceheriteclasse(char* nom){
	boolean result=false;
	termeType* tt=file2->firstTerme;
	while(tt->nextTerme!=NULL){
			if((strcmp(tt->nom,nom)==0)&&(strcmp(tt->type,"interface")==0)){
				int i=0;
				while(i<(tt->nbHeri)){
					if(strcmp(tt->herinter[i]->type,"class")==0){result=true;break;}
					i++;
				}
				break;
			}
		tt=tt->nextTerme;
	}
	return result;
}

boolean interfacedeclareclass(char* nom){
	boolean result=false;
	termeType* tt=file2->firstTerme;
	while(tt->nextTerme!=NULL){
		if((strcmp(tt->nom,nom)==0)&&(strcmp(tt->type,"interface")==0)){
			int i=0;
			while(i<(tt->nbClassesFilles)){
				if(strcmp(tt->listeClassDecl[i]->type,"class")==0){result=true;break;}
				i++;
			}
		}
		tt=tt->nextTerme;	
	}
	return result;
}

boolean classfilleestheritee(char* nom){
	boolean result=false;
	termeType* tt=file2->firstTerme;
	while(tt->nextTerme!=NULL){
		if(strcmp(tt->nom,nom)==0){
			int i=0;
			while(i<(tt->nbHeri)){
				if(false)printf("%d eteet %d\n",tt->herinter[i]->niveau,tt->niveau);
				if(tt->herinter[i]->niveau>tt->niveau){result=true;break;}
				i++;
			}
		}
		tt=tt->nextTerme;	
	}
	return result;
}
