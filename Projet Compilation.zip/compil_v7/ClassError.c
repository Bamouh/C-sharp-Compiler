#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "Class.h"
#include "ClassError.h"
#include<string.h>

fileErr* file;

void creer_file_erreur(){
	Error* err = malloc(sizeof(Error));
	strcpy(err->terme,"null");
	err->ligne=0;
	err->type=Other;
	strcpy(err->comment,"null");
	err->nextErr=NULL;
	file = malloc(sizeof(fileErr));
	file->firstErr=err;
}

void creer_sm_erreur_class(ErrorType et, int line, char* name,char* comment){
	Error* err = malloc(sizeof(Error));
	strcpy(err->terme,name);
	err->type=et;
	strcpy(err->comment,comment);
	err->nextErr=file->firstErr;
	file->firstErr=err;
	//printf("Erreur dans la classe %s (%s)\n",err->terme,err->comment);
}

int nombre_sm_erreurs_class(){
	int c=0;
	Error* err=file->firstErr;
	while(err->nextErr!=NULL){
		c++;
		err=err->nextErr;
	}
	return c;
}

void afficher_sm_erreurs_class(){
	Error* err=file->firstErr;
	if(file->firstErr==NULL){
		if(false)printf("Aucune erreur détectée.");
	}
	else{
		if(false)printf("%d erreurs.\n",nombre_sm_erreurs_class());
	}
	while(err->nextErr!=NULL){
		if(err->type==CDD){
			if(false)printf("ligne %d : %s %s (%s).\n",err->ligne,err->terme,"Classe dèja déclarée",err->comment);
		}
		else if(err->type==IM){
			if(false)printf("ligne %d : %s %s (%s).\n",err->ligne,err->terme,"Modificateur incorrect",err->comment);
		}
		else if(err->type==HE){
			if(false)printf("ligne %d : %s %s (%s).\n",err->ligne,err->terme,"Erreur d'héritage",err->comment);
		}
		else if(err->type==IE){
			if(false)printf("ligne %d : %s %s (%s).\n",err->ligne,err->terme,"Erreur d'interface",err->comment);
		}
		err=err->nextErr;
	}
}
